@echo off
chcp 65001 >nul
title CAMPRO ASP.NET Core + MySQL
setlocal

set "CAMPRO_ROOT=%~dp0"
set "PROJECT=%CAMPRO_ROOT%CamPro.Web\CamPro.Web.csproj"
set "MYSQL_ADMIN=C:\xampp\mysql\bin\mysqladmin.exe"
set "MYSQL_SERVER=C:\xampp\mysql\bin\mysqld.exe"
set "MYSQL_INI=C:\xampp\mysql\bin\my.ini"

if not exist "%PROJECT%" (
  echo Không tìm thấy dự án: %PROJECT%
  pause
  exit /b 1
)

if not exist "%MYSQL_SERVER%" (
  echo Không tìm thấy MySQL trong C:\xampp.
  echo Hãy cài XAMPP hoặc sửa cấu hình Database trong appsettings.json.
  pause
  exit /b 1
)

"%MYSQL_ADMIN%" -h 127.0.0.1 -P 3306 -u root ping >nul 2>nul
if errorlevel 1 (
  echo Đang khởi động MySQL XAMPP...
  start "CAMPRO MySQL" /min "%MYSQL_SERVER%" --defaults-file="%MYSQL_INI%" --standalone
  timeout /t 4 /nobreak >nul
)

echo Đang khởi động CAMPRO tại http://localhost:5189
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 4; Start-Process 'http://localhost:5189'"
dotnet run --project "%PROJECT%" --urls "http://localhost:5189"

endlocal
