using System.Globalization;

using System.Net.Http.Json;

using System.Security.Cryptography;

using System.Text;

using System.Text.Json;

using Microsoft.Extensions.Caching.Memory;

using Microsoft.Extensions.Primitives;


namespace CamPro.Web.Services;


public sealed partial class VnPayService
{

    private static readonly string[] QueryRequestFields = [
        "vnp_RequestId", "vnp_Version", "vnp_Command", "vnp_TmnCode", "vnp_TxnRef",
        "vnp_TransactionDate", "vnp_CreateDate", "vnp_IpAddr", "vnp_OrderInfo"];

    private static readonly string[] QueryResponseFields = [
        "vnp_ResponseId", "vnp_Command", "vnp_ResponseCode", "vnp_Message", "vnp_TmnCode",
        "vnp_TxnRef", "vnp_Amount", "vnp_BankCode", "vnp_PayDate", "vnp_TransactionNo",
        "vnp_TransactionType", "vnp_TransactionStatus", "vnp_OrderInfo", "vnp_PromotionCode",
        "vnp_PromotionAmount"];


    private string QueryChecksum(Dictionary<string, string> values, IEnumerable<string> fields)
    {

        var data = string.Join("|", fields.Select(field => values.GetValueOrDefault(field, "")));

        return Convert.ToHexString(HMACSHA512.HashData(
            Encoding.UTF8.GetBytes(options.CurrentValue.HashSecret), Encoding.UTF8.GetBytes(data)))
            .ToLowerInvariant();

    }


    /// <summary>Accept only a signed, matching payment transaction from VNPay's server API.</summary>
    public bool VerifyQueryResponse(Dictionary<string, string> response, string reference)
    {

        if (!IsConfigured || response.GetValueOrDefault("vnp_TmnCode") != options.CurrentValue.TmnCode ||
            response.GetValueOrDefault("vnp_TxnRef") != reference ||
            response.GetValueOrDefault("vnp_ResponseCode") != "00" ||
            response.GetValueOrDefault("vnp_TransactionType") != "01" ||
            response.GetValueOrDefault("vnp_Command") is not (null or "" or "querydr")) return false;

        var signature = response.GetValueOrDefault("vnp_SecureHash", "");

        if (signature.Length != 128) return false;

        try
        {

            return CryptographicOperations.FixedTimeEquals(Convert.FromHexString(signature),
                Convert.FromHexString(QueryChecksum(response, QueryResponseFields)));

        }

        catch (FormatException)
        {
            return false;
        }

    }


    /// <summary>Recover delayed IPN confirmations, including when running on localhost.</summary>
    public async Task ReconcileOrderAsync(string orderId, string ip, CancellationToken ct)
    {

        if (!IsConfigured || !options.CurrentValue.EnableQueryReconciliation) return;

        await using var cn = factory.Create();

        await cn.OpenAsync(ct);

        var attempts = new List<(string Reference, DateTime Created)>();

        await using (var cmd = Command(cn, null,
            "SELECT a.reference,a.created_at FROM payment_attempts a JOIN orders o ON o.id=a.order_id " +
            "WHERE a.order_id=@id AND a.state='pending' AND o.paid=0 AND o.status<>'Đã hủy' " +
            "ORDER BY a.created_at DESC LIMIT 3", ("@id", orderId)))
        {

            await using var reader = await cmd.ExecuteReaderAsync(ct);

            while (await reader.ReadAsync(ct))
                attempts.Add((reader.GetString("reference"), reader.GetDateTime("created_at")));

        }

        foreach (var attempt in attempts)
        {

            var key = "vnp-query-" + attempt.Reference;

            if (cache.TryGetValue(key, out _)) continue;

            cache.Set(key, true, TimeSpan.FromSeconds(15));

            var request = new Dictionary<string, string>
            {

                ["vnp_RequestId"] = Guid.NewGuid().ToString("N"),
                ["vnp_Version"] = "2.1.0",
                ["vnp_Command"] = "querydr",
                ["vnp_TmnCode"] = options.CurrentValue.TmnCode,
                ["vnp_TxnRef"] = attempt.Reference,
                ["vnp_TransactionDate"] = attempt.Created.AddHours(7).ToString("yyyyMMddHHmmss"),
                ["vnp_CreateDate"] = DateTime.UtcNow.AddHours(7).ToString("yyyyMMddHHmmss"),
                ["vnp_IpAddr"] = ip,
                ["vnp_OrderInfo"] = "Kiem tra thanh toan don hang " + orderId
            }
;

            request["vnp_SecureHash"] = QueryChecksum(request, QueryRequestFields);

            try
            {

                var client = httpClients.CreateClient("VnPay");

                using var response = await client.PostAsJsonAsync(options.CurrentValue.QueryUrl, request, ct);

                if (!response.IsSuccessStatusCode) continue;

                using var document = await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync(ct), cancellationToken: ct);

                if (document.RootElement.ValueKind != JsonValueKind.Object) continue;

                var values = new Dictionary<string, string>(StringComparer.Ordinal);

                var duplicate = false;

                foreach (var property in document.RootElement.EnumerateObject())
                {

                    var value = property.Value.ValueKind == JsonValueKind.String ? property.Value.GetString() ?? "" : property.Value.ToString();

                    if (!values.TryAdd(property.Name, value)) duplicate = true;

                }

                if (duplicate || !VerifyQueryResponse(values, attempt.Reference)) continue;

                // Pending, reversed or refunded transactions do not constitute a completed payment.
                var status = values.GetValueOrDefault("vnp_TransactionStatus");

                if (status is not ("00" or "02")) continue;

                var result = await RecordVerifiedNotificationAsync(new QueryCollection(
                    values.ToDictionary(pair => pair.Key, pair => new StringValues(pair.Value))), ct);

                if (result.Code == "00" && status == "00") break;

            }

            catch (Exception ex) when (ex is HttpRequestException or JsonException ||
                (ex is OperationCanceledException && !ct.IsCancellationRequested))
            {

                logger.LogWarning("VNPay reconciliation temporarily unavailable for order {OrderId}.", orderId);

            }

        }

    }

}
