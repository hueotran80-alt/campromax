using System.Globalization;

using System.Net;

using System.Security.Cryptography;

using System.Text;

using CamPro.Web.Data;

using CamPro.Web.Models;

using CamPro.Web.Options;

using Microsoft.Extensions.Options;

using MySqlConnector;

namespace CamPro.Web.Services;

/// <summary>VNPay 2.1.0 signing and idempotent server notification processing.</summary>
public sealed partial class VnPayService(MySqlConnectionFactory factory, IOptionsMonitor<VnPayOptions> options, ILogger<VnPayService> logger, IHttpClientFactory httpClients, Microsoft.Extensions.Caching.Memory.IMemoryCache cache)
{

    public bool IsConfigured => options.CurrentValue.IsConfigured;

    private static string Canonical(IEnumerable<KeyValuePair<string, string>> values) => string.Join("&", values.Where(x => !string.IsNullOrEmpty(x.Value) && x.Key.StartsWith("vnp_", StringComparison.Ordinal) && x.Key is not "vnp_SecureHash" and not "vnp_SecureHashType").OrderBy(x => x.Key, StringComparer.Ordinal).Select(x => WebUtility.UrlEncode(x.Key) + "=" + WebUtility.UrlEncode(x.Value)));

    public string Sign(IEnumerable<KeyValuePair<string, string>> values) => Convert.ToHexString(HMACSHA512.HashData(Encoding.UTF8.GetBytes(options.CurrentValue.HashSecret), Encoding.UTF8.GetBytes(Canonical(values)))).ToLowerInvariant();

    public bool Verify(IQueryCollection query)
    {

        if (!IsConfigured || query.Any(x => x.Key.StartsWith("vnp_", StringComparison.Ordinal) && x.Value.Count != 1)) return false;

        var supplied = query["vnp_SecureHash"].ToString();
        if (supplied.Length != 128) return false;

        try
        {
            return CryptographicOperations.FixedTimeEquals(Convert.FromHexString(supplied), Convert.FromHexString(Sign(query.Select(x => new KeyValuePair<string, string>(x.Key, x.Value.ToString())))));
        }
        catch (FormatException)
        {
            return false;
        }

    }

    private static MySqlCommand Command(MySqlConnection cn, MySqlTransaction? tx, string sql, params (string, object?)[] args)
    {
        var cmd = new MySqlCommand(sql, cn, tx);
        foreach (var (k, v) in args) cmd.Parameters.AddWithValue(k, v ?? DBNull.Value);
        return cmd;
    }

    public async Task<string> CreateUrlAsync(string orderId, string ownerEmail, string ip, CancellationToken ct)
    {

        var config = options.CurrentValue;
        if (!config.IsConfigured) throw new InvalidOperationException("VNPay chưa được cấu hình.");

        if (!Uri.TryCreate(config.PublicBaseUrl, UriKind.Absolute, out var baseUrl) || baseUrl.Scheme is not ("https" or "http")) throw new InvalidOperationException("Địa chỉ website chưa hợp lệ.");

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);

        decimal amount;
        string payment, status, email;
        bool paid;

        await using (var cmd = Command(cn, tx, "SELECT total,payment,paid,status,email FROM orders WHERE id=@id FOR UPDATE", ("@id", orderId)))
        {
            await using var r = await cmd.ExecuteReaderAsync(ct);
            if (!await r.ReadAsync(ct)) throw new InvalidOperationException("Không tìm thấy đơn hàng.");
            amount = r.GetDecimal("total");
            payment = r.GetString("payment");
            paid = r.GetBoolean("paid");
            status = r.GetString("status");
            email = r.GetString("email");
        }

        if (!email.Equals(ownerEmail, StringComparison.OrdinalIgnoreCase) || payment != "VNPay" || paid || status != "Chờ xử lý") throw new InvalidOperationException("Đơn hàng không thể thanh toán VNPay.");

        if (amount < 5000 || amount * 100 > 999999999999) throw new InvalidOperationException("Số tiền nằm ngoài giới hạn VNPay.");

        string reference;
        DateTime created, expires;

        // Reuse an active attempt: repeated clicks cannot open multiple payable transactions for one order.
        await using (var cmd = Command(cn, tx, "SELECT reference,created_at,expires_at FROM payment_attempts WHERE order_id=@id AND state='pending' AND expires_at>UTC_TIMESTAMP() ORDER BY created_at DESC LIMIT 1 FOR UPDATE", ("@id", orderId)))
        {
            await using var r = await cmd.ExecuteReaderAsync(ct);
            if (await r.ReadAsync(ct))
            {
                reference = r.GetString("reference");
                created = DateTime.SpecifyKind(r.GetDateTime("created_at"), DateTimeKind.Utc);
                expires = DateTime.SpecifyKind(r.GetDateTime("expires_at"), DateTimeKind.Utc);
            }
            else
            {
                reference = "VP" + Guid.NewGuid().ToString("N");
                created = DateTime.UtcNow;
                expires = created.AddMinutes(15);
            }
        }

        await using (var cmd = Command(cn, tx, "INSERT IGNORE INTO payment_attempts(reference,order_id,amount,created_at,expires_at) VALUES(@r,@o,@a,@c,@e)", ("@r", reference), ("@o", orderId), ("@a", amount), ("@c", created), ("@e", expires))) await cmd.ExecuteNonQueryAsync(ct);

        await tx.CommitAsync(ct);

        var values = new SortedDictionary<string, string>(StringComparer.Ordinal)
        {

            ["vnp_Version"] = "2.1.0",
            ["vnp_Command"] = "pay",
            ["vnp_TmnCode"] = config.TmnCode,
            ["vnp_Amount"] = (amount * 100).ToString("0", CultureInfo.InvariantCulture),
            ["vnp_CurrCode"] = "VND",
            ["vnp_TxnRef"] = reference,
            ["vnp_OrderInfo"] = "Thanh toan don hang " + orderId,
            ["vnp_OrderType"] = "other",
            ["vnp_Locale"] = "vn",
            ["vnp_ReturnUrl"] = config.PublicBaseUrl.TrimEnd('/') + "/Payment/Return",
            ["vnp_IpAddr"] = ip,
            ["vnp_CreateDate"] = created.AddHours(7).ToString("yyyyMMddHHmmss"),
            ["vnp_ExpireDate"] = expires.AddHours(7).ToString("yyyyMMddHHmmss")
        }
;

        return config.Url + "?" + Canonical(values) + "&vnp_SecureHash=" + Sign(values);

    }

    public async Task<(string Code, string Message)> ProcessIpnAsync(IQueryCollection query, CancellationToken ct)
    {

        if (!Verify(query) || query["vnp_TmnCode"] != options.CurrentValue.TmnCode) return ("97", "Invalid signature");

        return await RecordVerifiedNotificationAsync(query, ct);

    }

    private async Task<(string Code, string Message)> RecordVerifiedNotificationAsync(IQueryCollection query, CancellationToken ct)
    {

        if (!decimal.TryParse(query["vnp_Amount"], NumberStyles.None, CultureInfo.InvariantCulture, out var minor)) return ("04", "Invalid amount");

        var reference = query["vnp_TxnRef"].ToString();
        var response = query["vnp_ResponseCode"].ToString();
        var transactionStatus = query["vnp_TransactionStatus"].ToString();

        if (response.Length != 2 || transactionStatus.Length != 2) return ("99", "Invalid response");

        var orderId = await FindOrderAsync(reference, ct);

        if (orderId is null) return ("01", "Order not found");

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);

        decimal orderAmount;
        bool paid;
        string status;

        await using (var cmd = Command(cn, tx, "SELECT total,paid,status FROM orders WHERE id=@id FOR UPDATE", ("@id", orderId)))
        {
            await using var r = await cmd.ExecuteReaderAsync(ct);
            if (!await r.ReadAsync(ct)) return ("01", "Order not found");
            orderAmount = r.GetDecimal("total");
            paid = r.GetBoolean("paid");
            status = r.GetString("status");
        }

        // Use the same lock order as checkout/retry/cancellation: order, then payment attempt.
        string state;
        decimal expected;

        await using (var cmd = Command(cn, tx, "SELECT amount,state FROM payment_attempts WHERE reference=@r AND order_id=@o FOR UPDATE", ("@r", reference), ("@o", orderId)))
        {

            await using var r = await cmd.ExecuteReaderAsync(ct);

            if (!await r.ReadAsync(ct)) return ("01", "Order not found");

            expected = r.GetDecimal("amount");
            state = r.GetString("state");

        }

        if (minor != expected * 100 || expected != orderAmount) return ("04", "Invalid amount");

        if (state != "pending") return ("02", "Order already confirmed");

        var success = response == "00" && transactionStatus == "00";

        var transactionNo = query["vnp_TransactionNo"].ToString();

        if (success && (string.IsNullOrWhiteSpace(transactionNo) || transactionNo == "0" || transactionNo.Length > 50)) return ("99", "Invalid transaction");

        if (paid) return ("02", "Order already confirmed");

        // Payment notification and cancellation use row locks; paid orders cannot later be cancelled.
        if (success && status == "Đã hủy")
        {
            logger.LogWarning("Payment for cancelled order {OrderId} needs reconciliation.", orderId);
            return ("99", "Cancelled order requires reconciliation");
        }

        DateTime? paidAt = null;
        if (DateTime.TryParseExact(query["vnp_PayDate"], "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsed)) paidAt = parsed;

        if (success && paidAt is null) return ("99", "Invalid payment date");

        await using (var cmd = Command(cn, tx, "UPDATE payment_attempts SET state=@state,transaction_no=@no,response_code=@code,bank_code=@bank,paid_at=@date WHERE reference=@ref", ("@state", success ? "success" : "failed"), ("@no", success ? transactionNo : null), ("@code", response), ("@bank", query["vnp_BankCode"].ToString()[..Math.Min(30, query["vnp_BankCode"].ToString().Length)]), ("@date", paidAt), ("@ref", reference))) await cmd.ExecuteNonQueryAsync(ct);

        if (success)
        {
            await using var cmd = Command(cn, tx, "UPDATE orders SET paid=1 WHERE id=@id AND payment='VNPay' AND paid=0", ("@id", orderId));
            await cmd.ExecuteNonQueryAsync(ct);
        }

        await tx.CommitAsync(ct);
        logger.LogInformation("VNPay notification recorded for order {OrderId}, success {Success}.", orderId, success);
        return ("00", "Confirm success");

    }

    public async Task<string?> FindOrderAsync(string reference, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var cmd = Command(cn, null, "SELECT order_id FROM payment_attempts WHERE reference=@r", ("@r", reference));
        return await cmd.ExecuteScalarAsync(ct) as string;
    }

}
