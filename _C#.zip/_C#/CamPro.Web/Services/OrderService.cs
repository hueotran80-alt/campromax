using CamPro.Web.Data;

using CamPro.Web.Models;

using MySqlConnector;

namespace CamPro.Web.Services;

/// <summary>Authoritative pricing, inventory and fulfillment. Browser values never determine paid status.</summary>
public sealed class OrderService(MySqlConnectionFactory factory)
{

    private static MySqlCommand Command(MySqlConnection cn, MySqlTransaction tx, string sql, params (string, object?)[] args)
    {
        var cmd = new MySqlCommand(sql, cn, tx);
        foreach (var (key, value) in args) cmd.Parameters.AddWithValue(key, value ?? DBNull.Value);
        return cmd;
    }

    public async Task<string> CreateAsync(long userId, CheckoutForm form, CancellationToken ct)
    {

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);

        // Lock the buyer first: duplicate submissions serialize even when their token is not yet inserted.
        string email;

        await using (var cmd = Command(cn, tx, "SELECT email FROM users WHERE id=@id AND active=1 FOR UPDATE", ("@id", userId))) email = await cmd.ExecuteScalarAsync(ct) as string ?? throw new InvalidOperationException("Tài khoản không còn hoạt động.");

        await using (var cmd = Command(cn, tx, "SELECT order_id FROM checkout_submissions WHERE token=@t AND user_id=@u", ("@t", form.SubmissionToken), ("@u", userId))) if (await cmd.ExecuteScalarAsync(ct) is string existing)
        {
            await tx.CommitAsync(ct);
            return existing;
        }

        var lines = new List<OrderItemDto>();

        await using (var cmd = Command(cn, tx, "SELECT p.*,c.quantity FROM carts c JOIN products p ON p.id=c.product_id WHERE c.user_id=@u ORDER BY p.id FOR UPDATE", ("@u", userId)))
        {

            await using var reader = await cmd.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {

                var q = reader.GetInt32("quantity");
                if (!reader.GetBoolean("active") || q <= 0 || q > reader.GetInt32("stock")) throw new InvalidOperationException("Sản phẩm hết hàng hoặc số lượng vượt tồn kho. Vui lòng kiểm tra giỏ hàng.");

                lines.Add(new()
                {
                    Id = reader.GetInt64("id"),
                    Name = reader.GetString("name"),
                    Image = reader.GetString("image"),
                    Price = reader.GetDecimal("price"),
                    Quantity = q
                }
);

            }

        }

        if (lines.Count == 0) throw new InvalidOperationException("Giỏ hàng đang trống.");

        var subtotal = lines.Sum(x => x.Price * x.Quantity);
        decimal discount = 0;

        if (!string.IsNullOrWhiteSpace(form.Coupon))
        {
            await using var cmd = Command(cn, tx, "SELECT * FROM coupons WHERE code=@code AND active=1 FOR UPDATE", ("@code", form.Coupon.Trim()));
            await using var r = await cmd.ExecuteReaderAsync(ct);
            if (!await r.ReadAsync(ct) || subtotal < r.GetDecimal("min_amount")) throw new InvalidOperationException("Mã giảm giá không còn hợp lệ.");
            discount = CartService.Discount(new()
            {
                Type = r.GetString("discount_type"),
                Value = r.GetDecimal("discount_value"),
                Min = r.GetDecimal("min_amount"),
                Max = r.GetDecimal("max_amount")
            }
           , subtotal);
        }

        if (form.Payment == "VNPay" && subtotal - discount < 5000) throw new InvalidOperationException("VNPay yêu cầu số tiền thanh toán tối thiểu 5.000đ.");

        var id = "CP" + Guid.NewGuid().ToString("N")[..20].ToUpperInvariant();

        await using (var cmd = Command(cn, tx, "INSERT INTO orders(id,customer,email,shipping_email,phone,address,note,order_date,total,discount,status,payment,paid,demo) VALUES(@id,@name,@email,@shipping,@phone,@address,@note,@date,@total,@discount,'Chờ xử lý',@payment,0,0)", ("@id", id), ("@name", form.Name), ("@email", email), ("@shipping", form.Email), ("@phone", form.Phone), ("@address", form.Address), ("@note", form.Note), ("@date", DateTime.UtcNow.AddHours(7).Date), ("@total", subtotal - discount), ("@discount", discount), ("@payment", form.Payment))) await cmd.ExecuteNonQueryAsync(ct);

        foreach (var x in lines)
        {
            await using (var cmd = Command(cn, tx, "INSERT INTO order_items(order_id,product_id,product_name,quantity,price,image) VALUES(@o,@p,@n,@q,@price,@i)", ("@o", id), ("@p", x.Id), ("@n", x.Name), ("@q", x.Quantity), ("@price", x.Price), ("@i", x.Image))) await cmd.ExecuteNonQueryAsync(ct);
            await using (var cmd = Command(cn, tx, "UPDATE products SET stock=stock-@q WHERE id=@p", ("@q", x.Quantity), ("@p", x.Id))) await cmd.ExecuteNonQueryAsync(ct);
        }

        await using (var cmd = Command(cn, tx, "INSERT INTO checkout_submissions(token,user_id,order_id) VALUES(@t,@u,@o)", ("@t", form.SubmissionToken), ("@u", userId), ("@o", id))) await cmd.ExecuteNonQueryAsync(ct);

        await using (var cmd = Command(cn, tx, "DELETE FROM carts WHERE user_id=@id", ("@id", userId))) await cmd.ExecuteNonQueryAsync(ct);

        await tx.CommitAsync(ct);
        return id;

    }

    public async Task UpdateStatusAsync(string id, string? ownerEmail, string status, bool? paid, CancellationToken ct)
    {

        string[] statuses = ["Chờ xử lý", "Đã xác nhận", "Đang giao", "Đã giao", "Hoàn thành", "Đã hủy"];
        if (!statuses.Contains(status)) throw new InvalidOperationException("Trạng thái không hợp lệ.");

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);

        string old, payment, email;
        bool wasPaid;

        await using (var cmd = Command(cn, tx, "SELECT status,payment,paid,email FROM orders WHERE id=@id FOR UPDATE", ("@id", id)))
        {
            await using var r = await cmd.ExecuteReaderAsync(ct);
            if (!await r.ReadAsync(ct)) throw new InvalidOperationException("Không tìm thấy đơn.");
            old = r.GetString("status");
            payment = r.GetString("payment");
            wasPaid = r.GetBoolean("paid");
            email = r.GetString("email");
        }

        if (ownerEmail is not null && (!string.Equals(ownerEmail, email, StringComparison.OrdinalIgnoreCase) || status != "Đã hủy" || old != "Chờ xử lý")) throw new InvalidOperationException("Không thể hủy đơn ở trạng thái hiện tại.");

        if (old == "Đã hủy" && status != old) throw new InvalidOperationException("Không thể mở lại đơn đã hủy.");

        if (old != status && status != "Đã hủy" && Array.IndexOf(statuses, status) != Array.IndexOf(statuses, old) + 1) throw new InvalidOperationException("Hãy cập nhật theo thứ tự: xác nhận, đang giao, đã giao, hoàn thành.");

        if (status == "Đã hủy" && (old == "Đã giao" || old == "Hoàn thành" || wasPaid)) throw new InvalidOperationException("Đơn đã thanh toán hoặc đã giao cần xử lý hoàn tiền/đổi trả, không thể hủy trực tiếp.");

        if (status == "Đã hủy" && payment == "VNPay")
        {

            await using var pending = Command(cn, tx,
                "SELECT COUNT(*) FROM payment_attempts WHERE order_id=@id AND state='pending'",
                ("@id", id));

            if (Convert.ToInt32(await pending.ExecuteScalarAsync(ct)) > 0)
                throw new InvalidOperationException("Giao dịch VNPay đang chờ kết quả. Vui lòng hoàn tất hoặc hủy giao dịch trên VNPay trước khi hủy đơn.");

        }

        if (payment == "VNPay" && !wasPaid && status != "Chờ xử lý" && status != "Đã hủy") throw new InvalidOperationException("Đơn VNPay chưa thanh toán thành công.");

        // Admin cannot set or clear the payment flag on any VNPay order.
        var nextPaid = payment == "VNPay" ? wasPaid : paid ?? wasPaid;

        if (status == "Đã hủy") nextPaid = false;

        if (status == "Hoàn thành" && !nextPaid) throw new InvalidOperationException("Đơn chưa thanh toán không thể hoàn thành.");

        if (status == "Đã hủy" && old != "Đã hủy")
        {

            await using var cmd = Command(cn, tx, "UPDATE products p JOIN order_items i ON i.product_id=p.id SET p.stock=p.stock+i.quantity WHERE i.order_id=@id", ("@id", id));
            await cmd.ExecuteNonQueryAsync(ct);

        }

        await using (var cmd = Command(cn, tx, "UPDATE orders SET status=@s,paid=@p WHERE id=@id", ("@s", status), ("@p", nextPaid), ("@id", id))) await cmd.ExecuteNonQueryAsync(ct);
        await tx.CommitAsync(ct);

    }

}
