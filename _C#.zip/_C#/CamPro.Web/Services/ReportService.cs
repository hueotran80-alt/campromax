using CamPro.Web.Data;

using CamPro.Web.Models;

namespace CamPro.Web.Services;

/// <summary>Report fulfilled sales from persisted order_items, preserving historical names/prices.</summary>
public sealed class ReportService(StoreRepository repository)
{

    public async Task<RevenueReport> BuildAsync(DateOnly from, DateOnly to, CancellationToken ct)
    {

        if (from > to) throw new ArgumentException("Ngày bắt đầu phải trước ngày kết thúc.");

        var state = await repository.GetStateAsync(null, ct);

        // Count only paid, fulfilled sales. Pending/unpaid/cancelled orders are not revenue.
        var orders = state.Orders.Where(o => !o.Demo && o.Paid && (o.Status == "Đã giao" || o.Status == "Hoàn thành") && DateOnly.TryParse(o.Date, out var date) && date >= from && date <= to).ToList();

        var sales = orders.SelectMany(order =>
        {

            var subtotal = order.Items.Sum(item => item.Price * item.Quantity);

            var revenueRatio = subtotal == 0 ? 0 : order.Total / subtotal;

            return order.Items.Select(item => new
            {

                OrderId = order.Id,
                Item = item,
                NetRevenue = item.Price * item.Quantity * revenueRatio
            }
);

        }
);

        var top = sales.GroupBy(sale => sale.Item.Id)
            .Select(group => new BestSeller(
                group.Key,
                group.First().Item.Name,
                group.First().Item.Image,
                group.Sum(sale => (long)sale.Item.Quantity),
                decimal.Round(group.Sum(sale => sale.NetRevenue)),
                group.Select(sale => sale.OrderId).Distinct().LongCount()))
            .OrderByDescending(product => product.Quantity)
            .ThenByDescending(product => product.Revenue)
            .ThenBy(product => product.ProductId)
            .Take(5)
            .ToList();

        return new(from, to, orders, top);

    }

}
