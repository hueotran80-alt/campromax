using System.Security.Claims;

using System.Text.Json;

using CamPro.Web.Data;

using CamPro.Web.Models;

namespace CamPro.Web.Services;


public sealed class CartService(StoreRepository repository, IHttpContextAccessor accessor)
{

    private HttpContext Context => accessor.HttpContext!;

    public long? UserId => long.TryParse(Context.User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : null;

    public async Task<List<CartItemDto>> ItemsAsync(CancellationToken ct)
    {
        if (UserId is
            {
            }
        id) return (await repository.GetStateAsync(id, ct)).Cart;
        return JsonSerializer.Deserialize<List<CartItemDto>>(Context.Session.GetString("cart") ?? "[]") ?? [];
    }

    public async Task SaveAsync(List<CartItemDto> items, CancellationToken ct)
    {
        if (UserId is
            {
            }
        id) await repository.SaveCartAsync(id, items, ct);
        else Context.Session.SetString("cart", JsonSerializer.Serialize(items));
    }

    public async Task MergeAsync(long userId, CancellationToken ct)
    {
        var guest = JsonSerializer.Deserialize<List<CartItemDto>>(Context.Session.GetString("cart") ?? "[]") ?? [];
        var state = await repository.GetStateAsync(userId, ct);
        var merged = state.Cart.Concat(guest).GroupBy(x => x.Id).Select(x => new CartItemDto
        {
            Id = x.Key,
            Quantity = Math.Min(99, x.Sum(i => i.Quantity))
        }
       ).Where(x => state.Products.Any(p => p.Id == x.Id && p.Active)).ToList();
        await repository.SaveCartAsync(userId, merged, ct);
        Context.Session.Remove("cart");
    }

    public async Task<CartView> ViewAsync(CancellationToken ct)
    {
        var state = await repository.GetStateAsync(UserId, ct);
        var items = UserId is null ? await ItemsAsync(ct) : state.Cart;
        var lines = items.Select(i => new CartLine(state.Products.FirstOrDefault(p => p.Id == i.Id && p.Active)!, i.Quantity)).Where(i => i.Product is not null).ToList();
        var code = Context.Session.GetString("coupon") ?? "";
        var sub = lines.Sum(x => x.Total);
        var coupon = state.Coupons.FirstOrDefault(x => x.Active && x.Code.Equals(code, StringComparison.OrdinalIgnoreCase));
        return new(lines, code, coupon is null ? 0 : Discount(coupon, sub));
    }

    public static decimal Discount(CouponDto coupon, decimal subtotal)
    {
        if (subtotal < coupon.Min) return 0;
        var value = coupon.Type == "percent" ? decimal.Floor(subtotal * coupon.Value / 100) : coupon.Value;
        if (coupon.Max > 0) value = Math.Min(value, coupon.Max);
        return Math.Min(value, subtotal);
    }

}
