using CamPro.Web.Data;

using CamPro.Web.Models;

using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.RateLimiting;

namespace CamPro.Web.Controllers;


public sealed class ContactController(StoreRepository repository) : StoreControllerBase(repository)
{
    [HttpGet] public IActionResult Index() => View(new ContactForm());
    [HttpPost, EnableRateLimiting("auth")]
    public async Task<IActionResult> Index(ContactForm f, CancellationToken ct)
    {
        if (!ModelState.IsValid) return View(f);
        await Repository.CreateContactAsync(f, ct);
        return MessageRedirect("Đã tiếp nhận yêu cầu tư vấn. CAMPRO sẽ liên hệ với bạn.", "Index", "Contact");
    }
}
