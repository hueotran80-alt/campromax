using System.Text.Json;

using CamPro.Web.Data;

using Microsoft.AspNetCore.Mvc;

namespace CamPro.Web.Controllers;


public sealed class ProductsController(StoreRepository repository) : StoreControllerBase(repository)
{

    public async Task<IActionResult> Index(string? q, string? category, string? brand, string? resolution, decimal? min, decimal? max, string? sort, CancellationToken ct)
    {

        var state = await Repository.GetStateAsync(UserId, ct);
        var list = state.Products.Where(p => p.Active);

        if (!string.IsNullOrWhiteSpace(q)) list = list.Where(x => (x.Name + " " + x.Subtitle + " " + x.Brand).Contains(q, StringComparison.OrdinalIgnoreCase));

        if (!string.IsNullOrEmpty(category)) list = list.Where(x => x.Category == category);
        if (!string.IsNullOrEmpty(brand)) list = list.Where(x => x.Brand == brand);
        if (!string.IsNullOrEmpty(resolution)) list = list.Where(x => x.Resolution == resolution);

        if (min is
            {
            }
 lo) list = list.Where(x => x.Price >= lo);
        if (max is
            {
            }
        hi) list = list.Where(x => x.Price <= hi);

        list = sort switch
        {
            "price-asc" => list.OrderBy(x => x.Price),
            "price-desc" => list.OrderByDescending(x => x.Price),
            "new" => list.OrderByDescending(x => x.Id),
            _ => list.OrderByDescending(x => x.Stock > 0).ThenBy(x => x.Id)
        }
;

        ViewBag.State = state;
        return View(list.ToList());

    }

    public async Task<IActionResult> Details(long id, CancellationToken ct)
    {
        var s = await Repository.GetStateAsync(UserId, ct);
        var p = s.Products.FirstOrDefault(x => x.Id == id && x.Active);
        if (p is null) return NotFound();
        ViewBag.Related = s.Products.Where(x => x.Active && x.Category == p.Category && x.Id != id).Take(4).ToList();
        return View(p);
    }

    [HttpPost]
    public IActionResult CompareAdd(long id)
    {
        var ids = JsonSerializer.Deserialize<List<long>>(HttpContext.Session.GetString("compare") ?? "[]") ?? [];
        if (!ids.Contains(id) && ids.Count < 3) ids.Add(id);
        HttpContext.Session.SetString("compare", JsonSerializer.Serialize(ids));
        return RedirectToAction(nameof(Compare));
    }

    [HttpPost]
    public IActionResult CompareRemove(long id)
    {
        var ids = JsonSerializer.Deserialize<List<long>>(HttpContext.Session.GetString("compare") ?? "[]") ?? [];
        ids.Remove(id);
        HttpContext.Session.SetString("compare", JsonSerializer.Serialize(ids));
        return RedirectToAction(nameof(Compare));
    }

    public async Task<IActionResult> Compare(CancellationToken ct)
    {
        var ids = JsonSerializer.Deserialize<List<long>>(HttpContext.Session.GetString("compare") ?? "[]") ?? [];
        return View((await Repository.GetStateAsync(UserId, ct)).Products.Where(x => x.Active && ids.Contains(x.Id)).ToList());
    }

}
