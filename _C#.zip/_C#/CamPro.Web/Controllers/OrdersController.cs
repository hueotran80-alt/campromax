using CamPro.Web.Data;

using CamPro.Web.Services;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

namespace CamPro.Web.Controllers;


[Authorize]
public sealed class OrdersController(StoreRepository repository, OrderService orders, VnPayService vnPay) : StoreControllerBase(repository)
{

    public async Task<IActionResult> Index(CancellationToken ct) => View((await Repository.GetStateAsync(UserId, ct)).Orders.Where(x => x.Email.Equals(Email, StringComparison.OrdinalIgnoreCase)).ToList());

    public async Task<IActionResult> Details(string id, CancellationToken ct)
    {
        var o = await OwnedOrderAsync(id, ct);
        return o is null ? NotFound() : View(o);
    }

    [HttpPost]
    public async Task<IActionResult> Cancel(string id, CancellationToken ct)
    {
        try
        {
            await orders.UpdateStatusAsync(id, Email, "Đã hủy", null, ct);
            TempData["Message"] = "Đã hủy đơn hàng.";
        }
        catch (InvalidOperationException ex)
        {
            TempData["Message"] = ex.Message;
        }
        return RedirectToAction(nameof(Details), new
        {
            id
        }
       );
    }

    [HttpGet]
    public async Task<IActionResult> PaymentStatus(string id, CancellationToken ct)
    {

        var order = await OwnedOrderAsync(id, ct);

        if (order is null) return NotFound();

        if (order.Payment == "VNPay" && !order.Paid)
        {

            await vnPay.ReconcileOrderAsync(id, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1", ct);

            order = await OwnedOrderAsync(id, ct);

        }

        Response.Headers["Cache-Control"] = "no-store";

        return Json(new
        {
            paid = order!.Paid,
            status = order.Paid ? "Đã thanh toán" : "Chưa thanh toán"
        }
);

    }

}
