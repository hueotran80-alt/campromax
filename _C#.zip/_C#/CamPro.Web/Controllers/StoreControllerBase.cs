using System.Security.Claims;

using CamPro.Web.Data;

using CamPro.Web.Models;

using Microsoft.AspNetCore.Mvc;

namespace CamPro.Web.Controllers;


public abstract class StoreControllerBase(StoreRepository repository) : Controller
{

    protected StoreRepository Repository
    {
        get;
    }
 = repository;

    protected long? UserId => long.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : null;

    protected string Email => User.FindFirstValue(ClaimTypes.Email) ?? "";

    protected async Task<OrderDto?> OwnedOrderAsync(string id, CancellationToken ct) => (await Repository.GetStateAsync(UserId, ct)).Orders.FirstOrDefault(x => x.Id == id && x.Email.Equals(Email, StringComparison.OrdinalIgnoreCase));

    protected IActionResult MessageRedirect(string message, string action, string controller, object? route = null)
    {
        TempData["Message"] = message;
        return RedirectToAction(action, controller, route);
    }

}
