using CamPro.Web.Data;

using Microsoft.AspNetCore.Mvc;

namespace CamPro.Web.Controllers;


public sealed class NewsController(StoreRepository repository) : StoreControllerBase(repository)
{
    public async Task<IActionResult> Index(CancellationToken ct) => View((await Repository.GetStateAsync(null, ct)).Articles.Where(x => x.Published).ToList());
    public async Task<IActionResult> Details(long id, CancellationToken ct)
    {
        var a = (await Repository.GetStateAsync(null, ct)).Articles.FirstOrDefault(x => x.Id == id && x.Published);
        return a is null ? NotFound() : View(a);
    }
}
