using System.Globalization;

using System.Text;

using CamPro.Web.Data;

using CamPro.Web.Models;

using CamPro.Web.Services;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using MySqlConnector;

namespace CamPro.Web.Controllers;


[Authorize(Roles = "admin")]
public sealed class AdminController(StoreRepository repository, OrderService orders, ReportService reports) : StoreControllerBase(repository)
{

    public async Task<IActionResult> Index(CancellationToken ct) => View(await Repository.GetStateAsync(UserId, ct));

    public async Task<IActionResult> Orders(string? q, string? status, CancellationToken ct)
    {
        var list = (await Repository.GetStateAsync(UserId, ct)).Orders.Where(x => string.IsNullOrEmpty(status) || x.Status == status).Where(x => string.IsNullOrWhiteSpace(q) || (x.Id + " " + x.Customer + " " + x.Email).Contains(q, StringComparison.OrdinalIgnoreCase)).ToList();
        return View(list);
    }

    public async Task<IActionResult> OrderDetails(string id, CancellationToken ct)
    {
        var order = (await Repository.GetStateAsync(UserId, ct)).Orders.FirstOrDefault(x => x.Id == id);
        return order is null ? NotFound() : View(order);
    }

    [HttpPost]
    public async Task<IActionResult> OrderStatus(string id, string status, bool paid, CancellationToken ct)
    {
        try
        {
            await orders.UpdateStatusAsync(id, null, status, paid, ct);
            TempData["Message"] = "Đã cập nhật trạng thái đơn.";
        }
        catch (InvalidOperationException ex)
        {
            TempData["Message"] = ex.Message;
        }
        return RedirectToAction(nameof(OrderDetails), new
        {
            id
        }
       );
    }

    public async Task<IActionResult> Reports(DateOnly? from, DateOnly? to, CancellationToken ct)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow.AddHours(7));
        var start = from ?? new DateOnly(today.Year, today.Month, 1);
        var end = to ?? today;
        if (start > end)
        {
            TempData["Message"] = "Ngày bắt đầu phải trước ngày kết thúc.";
            end = start;
        }
        return View(await reports.BuildAsync(start, end, ct));
    }

    public async Task<IActionResult> Export(DateOnly from, DateOnly to, CancellationToken ct)
    {
        if (from > to) return BadRequest("Khoảng ngày chưa hợp lệ.");
        var report = await reports.BuildAsync(from, to, ct);
        var csv = new StringBuilder("\uFEFFMã đơn,Ngày đặt,Khách hàng,Doanh thu sau giảm giá\r\n");
        static string Cell(object? value)
        {
            var v = Convert.ToString(value, CultureInfo.InvariantCulture) ?? "";
            if (v.Length > 0 && "=+-@\t\r".Contains(v[0])) v = "'" + v;
            return "\"" + v.Replace("\"", "\"\"") + "\"";
        }
        foreach (var o in report.Orders) csv.AppendLine(string.Join(',', Cell(o.Id), Cell(o.Date), Cell(o.Customer), Cell(o.Total)));
        csv.AppendLine("\r\nTop 5 sản phẩm bán chạy,Số lượng,Số đơn,Doanh thu phân bổ");
        foreach (var p in report.BestSellers) csv.AppendLine(string.Join(',', Cell(p.Name), Cell(p.Quantity), Cell(p.OrderCount), Cell(p.Revenue)));
        return File(Encoding.UTF8.GetBytes(csv.ToString()), "text/csv; charset=utf-8", "CAMPRO-doanh-thu.csv");
    }

    public async Task<IActionResult> Customers(string? q, CancellationToken ct)
    {
        var s = await Repository.GetStateAsync(UserId, ct);
        ViewBag.Orders = s.Orders;
        return View(s.Customers.Where(x => string.IsNullOrWhiteSpace(q) || (x.Name + x.Email + x.Phone).Contains(q, StringComparison.OrdinalIgnoreCase)).ToList());
    }

    [HttpPost]
    public async Task<IActionResult> CustomerActive(long id, bool active, CancellationToken ct)
    {
        await Repository.SetCustomerActiveAsync(id, active, ct);
        return RedirectToAction(nameof(Customers));
    }

    public async Task<IActionResult> Contacts(CancellationToken ct) => View((await Repository.GetStateAsync(UserId, ct)).Contacts);

    [HttpPost]
    public async Task<IActionResult> Reply(long id, string reply, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(reply) || reply.Length > 5000) return BadRequest();
        await Repository.ReplyContactAsync(id, reply, ct);
        return MessageRedirect("Đã lưu phản hồi.", "Contacts", "Admin");
    }

    private static readonly Dictionary<string, (Type Type, string Title, string[] Properties)> Entities = new()
    {

        ["Products"] = (typeof(ProductDto), "Sản phẩm", ["Name", "Subtitle", "Brand", "Category", "Resolution", "Connection", "Price", "OldPrice", "Stock", "Image", "Tag", "Angle", "Night", "Description", "Active"]),
        ["Categories"] = (typeof(CategoryDto), "Danh mục", ["Name", "Description", "Active"]),
        ["Suppliers"] = (typeof(SupplierDto), "Nhà cung cấp", ["Name", "Description", "Email", "Phone", "Active"]),
        ["Coupons"] = (typeof(CouponDto), "Mã giảm giá", ["Code", "Type", "Value", "Min", "Max", "Active"]),
        ["Articles"] = (typeof(ArticleDto), "Bài viết", ["Title", "Category", "Image", "Body", "Published"])
    }
;

    private static readonly Dictionary<string, string> Labels = new()
    {
        ["Name"] = "Tên",
        ["Subtitle"] = "Mô tả ngắn",
        ["Brand"] = "Thương hiệu",
        ["Category"] = "Danh mục",
        ["Resolution"] = "Độ phân giải",
        ["Connection"] = "Kết nối",
        ["Price"] = "Giá bán (đ)",
        ["OldPrice"] = "Giá niêm yết (đ)",
        ["Stock"] = "Tồn kho",
        ["Image"] = "Tên ảnh trong assets hoặc URL /uploads/...",
        ["Tag"] = "Nhãn sản phẩm",
        ["Angle"] = "Góc quan sát",
        ["Night"] = "Chế độ ban đêm",
        ["Description"] = "Mô tả",
        ["Active"] = "Hoạt động / hiển thị",
        ["Email"] = "Email",
        ["Phone"] = "Điện thoại",
        ["Code"] = "Mã ưu đãi",
        ["Type"] = "Loại giảm (percent / fixed)",
        ["Value"] = "Mức giảm",
        ["Min"] = "Đơn tối thiểu",
        ["Max"] = "Giảm tối đa (0: không giới hạn)",
        ["Title"] = "Tiêu đề",
        ["Body"] = "Nội dung",
        ["Published"] = "Công bố"
    }
;

    private static IEnumerable<object> Items(StoreState s, string entity) => entity switch
    {
        "Products" => s.Products,
        "Categories" => s.Categories,
        "Suppliers" => s.Suppliers,
        "Coupons" => s.Coupons,
        "Articles" => s.Articles,
        _ => []
    }
;

    public async Task<IActionResult> Catalog(string entity = "Products", string? q = null, CancellationToken ct = default)
    {
        if (!Entities.ContainsKey(entity)) return NotFound();
        var state = await Repository.GetStateAsync(UserId, ct);
        ViewBag.Entity = entity;
        ViewBag.Title = Entities[entity].Title;
        ViewBag.State = state;
        return View(Items(state, entity).Where(x => string.IsNullOrWhiteSpace(q) || string.Join(" ", Entities[entity].Properties.Select(n => x.GetType().GetProperty(n)!.GetValue(x))).Contains(q, StringComparison.OrdinalIgnoreCase)).ToList());
    }

    private static AdminEditView Describe(string entity, long id, object item)
    {
        var meta = Entities[entity];
        return new(entity, id, meta.Title, meta.Properties.Select(n =>
        {
            var p = meta.Type.GetProperty(n)!;
            var value = p.GetValue(item);
            var type = p.PropertyType == typeof(bool) ? "checkbox" : p.PropertyType == typeof(int) || p.PropertyType == typeof(decimal) ? "number" : n is "Description" or "Body" ? "textarea" : "text";
            return new EditField(n, Labels[n], Convert.ToString(value, CultureInfo.InvariantCulture) ?? "", type);
        }
       ).ToList());
    }

    [HttpGet]
    public async Task<IActionResult> Edit(string entity, long id, CancellationToken ct)
    {
        if (!Entities.TryGetValue(entity, out var meta)) return NotFound();
        object? item = id == 0 ? Activator.CreateInstance(meta.Type) : Items(await Repository.GetStateAsync(UserId, ct), entity).FirstOrDefault(x => (long)x.GetType().GetProperty("Id")!.GetValue(x)! == id);
        if (item is null) return NotFound();
        if (id == 0)
        {
            meta.Type.GetProperty("Active")?.SetValue(item, true);
            meta.Type.GetProperty("Published")?.SetValue(item, true);
        }
        return View(Describe(entity, id, item));
    }

    [HttpPost]
    public async Task<IActionResult> Edit(string entity, long id, IFormCollection form, CancellationToken ct)
    {

        if (!Entities.TryGetValue(entity, out var meta)) return NotFound();
        var item = Activator.CreateInstance(meta.Type)!;
        meta.Type.GetProperty("Id")!.SetValue(item, id == 0 ? DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() : id);

        foreach (var name in meta.Properties)
        {
            var p = meta.Type.GetProperty(name)!;
            var text = form[name].ToString();
            try
            {
                object value = p.PropertyType == typeof(bool) ? form[name].Any(x => x == "true") : p.PropertyType == typeof(int) ? int.Parse(text, CultureInfo.InvariantCulture) : p.PropertyType == typeof(decimal) ? decimal.Parse(text, CultureInfo.InvariantCulture) : text.Trim();
                p.SetValue(item, value);
            }
            catch (FormatException)
            {
                ModelState.AddModelError(name, "Giá trị chưa hợp lệ.");
            }
            catch (OverflowException)
            {
                ModelState.AddModelError(name, "Giá trị quá lớn.");
            }
        }

        string title = Convert.ToString(meta.Type.GetProperty(entity == "Articles" ? "Title" : entity == "Coupons" ? "Code" : "Name")!.GetValue(item)) ?? "";
        if (string.IsNullOrWhiteSpace(title) || title.Length > 120) ModelState.AddModelError("", "Tên/tiêu đề cần từ 1–120 ký tự.");

        foreach (var name in meta.Properties)
        {
            var p = meta.Type.GetProperty(name)!;
            if (p.PropertyType == typeof(string))
            {
                var limit = name is "Body" ? 50000 : name == "Description" ? (entity == "Products" ? 5000 : 500) : name == "Phone" ? 30 : name == "Code" ? 50 : name == "Email" ? 160 : name is "Brand" or "Category" ? 120 : name is "Resolution" or "Connection" or "Angle" or "Night" ? 80 : name == "Tag" ? 100 : 255;
                if (((string?)p.GetValue(item))?.Length > limit) ModelState.AddModelError(name, "Nội dung quá dài.");
            }
        }

        if (item is ProductDto product)
        {
            if (product.Price <= 0 || product.Price > 9999999999 || product.Stock < 0 || product.OldPrice < 0) ModelState.AddModelError("", "Giá bán phải dương và tồn kho không âm.");
            if (product.Image.Contains("..") || Uri.TryCreate(product.Image, UriKind.Absolute, out _) || (!product.Image.StartsWith("/uploads/") && product.Image.Contains('/'))) ModelState.AddModelError("Image", "Ảnh phải nằm trong assets hoặc uploads.");
        }

        if (item is CouponDto coupon && (coupon.Value <= 0 || coupon.Min < 0 || coupon.Max < 0 || coupon.Type is not ("percent" or "fixed") || (coupon.Type == "percent" && coupon.Value > 100))) ModelState.AddModelError("", "Điều kiện mã giảm giá chưa hợp lệ.");

        if (ModelState.IsValid) try
            {
                switch (item)
                {
                    case ProductDto p:
                        await Repository.SaveProductAsync(p, ct);
                        break;
                    case CategoryDto c:
                        await Repository.SaveCategoryAsync(c, ct);
                        break;
                    case SupplierDto s:
                        await Repository.SaveSupplierAsync(s, ct);
                        break;
                    case CouponDto c:
                        await Repository.SaveCouponAsync(c, ct);
                        break;
                    case ArticleDto a:
                        await Repository.SaveArticleAsync(a, ct);
                        break;
                }
                return MessageRedirect("Đã lưu thay đổi.", "Catalog", "Admin", new
                {
                    entity
                }
               );
            }
            catch (MySqlException ex) when (ex.Number == 1062)
            {
                ModelState.AddModelError("", "Tên hoặc mã này đã tồn tại.");
            }

        return View(Describe(entity, id, item));

    }

    [HttpPost]
    public async Task<IActionResult> Hide(string entity, long id, CancellationToken ct)
    {
        if (!Entities.ContainsKey(entity)) return NotFound();
        await Repository.HideEntityAsync(entity, id, ct);
        return MessageRedirect("Đã ẩn mục khỏi cửa hàng.", "Catalog", "Admin", new
        {
            entity
        }
       );
    }

}
