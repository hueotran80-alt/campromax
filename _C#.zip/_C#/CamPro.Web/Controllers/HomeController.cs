using CamPro.Web.Data;

using CamPro.Web.Models;

using Microsoft.AspNetCore.Mvc;

namespace CamPro.Web.Controllers;


public sealed class HomeController(StoreRepository repository) : StoreControllerBase(repository)
{

    public async Task<IActionResult> Index(string? category, CancellationToken ct)
    {
        ViewBag.Category = category ?? "Tất cả";
        return View(await Repository.GetStateAsync(UserId, ct));
    }

    public IActionResult Policy() => View();

    [HttpGet, HttpPost, IgnoreAntiforgeryToken]
    public IActionResult Error()
    {
        Response.StatusCode = 500;
        return View();
    }

    [HttpGet("/api/health")]
    public async Task<IActionResult> Health(CancellationToken ct) => Json(new
    {
        status = await Repository.PingAsync(ct) ? "ok" : "error",
        database = "campro_csharp"
    }
);

}
