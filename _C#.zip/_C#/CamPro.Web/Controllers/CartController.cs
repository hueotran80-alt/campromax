using CamPro.Web.Data;

using CamPro.Web.Models;

using CamPro.Web.Services;

using Microsoft.AspNetCore.Mvc;

namespace CamPro.Web.Controllers;


public sealed class CartController(StoreRepository repository, CartService cart) : StoreControllerBase(repository)
{

    public async Task<IActionResult> Index(CancellationToken ct) => View(await cart.ViewAsync(ct));

    [HttpPost]
    public async Task<IActionResult> Add(long id, int quantity = 1, CancellationToken ct = default)
    {
        var p = (await Repository.GetStateAsync(UserId, ct)).Products.FirstOrDefault(x => x.Id == id && x.Active);
        var items = await cart.ItemsAsync(ct);
        var current = items.FirstOrDefault(x => x.Id == id);
        if (p is null || quantity < 1 || quantity > 99 || (current?.Quantity ?? 0) + quantity > p.Stock) return MessageRedirect("Số lượng vượt tồn kho hoặc sản phẩm đã hết hàng.", "Index", "Cart");
        if (current is null) items.Add(new()
        {
            Id = id,
            Quantity = quantity
        }
       );
        else current.Quantity += quantity;
        await cart.SaveAsync(items, ct);
        return MessageRedirect("Đã thêm sản phẩm vào giỏ.", "Index", "Cart");
    }

    [HttpPost]
    public async Task<IActionResult> Update(long id, int quantity, CancellationToken ct)
    {
        var items = await cart.ItemsAsync(ct);
        var item = items.FirstOrDefault(x => x.Id == id);
        if (item is null) return RedirectToAction(nameof(Index));
        if (quantity == 0) items.Remove(item);
        else
        {
            var p = (await Repository.GetStateAsync(UserId, ct)).Products.FirstOrDefault(x => x.Id == id && x.Active);
            if (p is null || quantity < 1 || quantity > Math.Min(99, p.Stock)) return MessageRedirect("Số lượng vượt tồn kho.", "Index", "Cart");
            item.Quantity = quantity;
        }
        await cart.SaveAsync(items, ct);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Coupon(string? code, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(code))
        {
            HttpContext.Session.Remove("coupon");
            return RedirectToAction(nameof(Index));
        }
        var coupon = (await Repository.GetStateAsync(UserId, ct)).Coupons.FirstOrDefault(x => x.Active && x.Code.Equals(code.Trim(), StringComparison.OrdinalIgnoreCase));
        var view = await cart.ViewAsync(ct);
        if (coupon is null || view.Subtotal < coupon.Min) return MessageRedirect("Mã giảm giá không hợp lệ hoặc đơn chưa đạt giá trị tối thiểu.", "Index", "Cart");
        HttpContext.Session.SetString("coupon", coupon.Code);
        return RedirectToAction(nameof(Index));
    }

}
