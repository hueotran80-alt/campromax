using CamPro.Web.Data;

using CamPro.Web.Models;

using CamPro.Web.Services;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

namespace CamPro.Web.Controllers;


public sealed class PaymentController(StoreRepository repository, VnPayService vnPay, ILogger<PaymentController> logger) : StoreControllerBase(repository)
{

    [Authorize, HttpPost]
    public async Task<IActionResult> Start(string id, CancellationToken ct)
    {
        if (await OwnedOrderAsync(id, ct) is null) return NotFound();
        try
        {
            return Redirect(await vnPay.CreateUrlAsync(id, Email, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1", ct));
        }
        catch (InvalidOperationException ex)
        {
            return MessageRedirect(ex.Message, "Details", "Orders", new
            {
                id
            }
           );
        }
    }

    [AllowAnonymous, HttpGet]
    public async Task<IActionResult> Ipn(CancellationToken ct)
    {
        try
        {
            var r = await vnPay.ProcessIpnAsync(Request.Query, ct);
            return new JsonResult(new
            {
                RspCode = r.Code,
                Message = r.Message
            }
           , new System.Text.Json.JsonSerializerOptions
           {
               PropertyNamingPolicy = null
           }
           );
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError("VNPay IPN could not be recorded ({ErrorType}).", ex.GetType().Name);
            return new JsonResult(new
            {
                RspCode = "99",
                Message = "Unable to record notification"
            }
           , new System.Text.Json.JsonSerializerOptions
           {
               PropertyNamingPolicy = null
           }
           );
        }
    }

    [AllowAnonymous, HttpGet]
    public async Task<IActionResult> Return(CancellationToken ct)
    {

        Response.Headers["Cache-Control"] = "no-store";
        Response.Headers["Referrer-Policy"] = "no-referrer";

        var valid = vnPay.Verify(Request.Query);
        string? id = valid ? await vnPay.FindOrderAsync(Request.Query["vnp_TxnRef"].ToString(), ct) : null;

        var order = id is null ? null : (await Repository.GetStateAsync(null, ct)).Orders.FirstOrDefault(x => x.Id == id);

        var matches = order is not null && Request.Query["vnp_TmnCode"] == HttpContext.RequestServices.GetRequiredService<Microsoft.Extensions.Options.IOptionsMonitor<CamPro.Web.Options.VnPayOptions>>().CurrentValue.TmnCode && decimal.TryParse(Request.Query["vnp_Amount"], out var amount) && amount == order.Total * 100;

        valid = valid && matches;
        var success = Request.Query["vnp_ResponseCode"] == "00" && Request.Query["vnp_TransactionStatus"] == "00";

        if (valid && order is
            {
                Paid: false
            }
)
        {

            await vnPay.ReconcileOrderAsync(id!, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1", ct);

            order = (await Repository.GetStateAsync(null, ct)).Orders.First(x => x.Id == id);

        }

        var message = !valid ? "Không thể xác minh kết quả thanh toán." : order!.Paid ? "Đơn hàng đã thanh toán thành công." : success ? "VNPay đã trả kết quả thành công. Hệ thống đang đồng bộ xác nhận thanh toán." : "Thanh toán chưa thành công hoặc bạn đã hủy giao dịch. Bạn có thể thanh toán lại trong chi tiết đơn hàng.";

        // Return query parameters never update payment state. Only verified IPN/querydr server data can do so.
        return View(new PaymentResultView(valid ? id : null, valid, Request.Query["vnp_ResponseCode"].ToString(), valid && order!.Paid, message));

    }

}
