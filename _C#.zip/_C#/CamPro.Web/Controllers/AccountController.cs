using System.Security.Claims;

using CamPro.Web.Data;

using CamPro.Web.Models;

using CamPro.Web.Services;

using Microsoft.AspNetCore.Authentication;

using Microsoft.AspNetCore.Authentication.Cookies;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.RateLimiting;

namespace CamPro.Web.Controllers;


public sealed class AccountController(StoreRepository repository, CartService cart, ILogger<AccountController> logger) : StoreControllerBase(repository)
{

    [HttpGet]
    public IActionResult Login(string? returnUrl) => View(new LoginForm
    {
        ReturnUrl = returnUrl
    }
);

    [HttpPost, EnableRateLimiting("auth")]
    public async Task<IActionResult> Login(LoginForm f, CancellationToken ct)
    {
        if (!ModelState.IsValid) return View(f);
        var user = await Repository.LoginAsync(f.Email, f.Password, ct);
        if (user is null)
        {
            logger.LogWarning("Rejected account login.");
            ModelState.AddModelError("", "Email hoặc mật khẩu không đúng, hoặc tài khoản đã bị khóa.");
            return View(f);
        }
        await SignInAsync(user, ct);
        return Url.IsLocalUrl(f.ReturnUrl) ? LocalRedirect(f.ReturnUrl!) : RedirectToAction("Index", user.Role == "admin" ? "Admin" : "Home");
    }

    [HttpGet] public IActionResult Register() => View(new RegisterForm());

    [HttpPost, EnableRateLimiting("auth")]
    public async Task<IActionResult> Register(RegisterForm f, CancellationToken ct)
    {
        if (f.Password.Length < 8) ModelState.AddModelError("Password", "Mật khẩu cần ít nhất 8 ký tự.");
        if (!ModelState.IsValid) return View(f);
        var result = await Repository.RegisterAsync(new(f.Name, f.Email, f.Password), ct);
        if (result.User is null)
        {
            ModelState.AddModelError("", result.Error!);
            return View(f);
        }
        await SignInAsync(result.User, ct);
        return RedirectToAction("Profile");
    }

    private async Task SignInAsync(CustomerDto user, CancellationToken ct)
    {
        await cart.MergeAsync(user.Id, ct);
        var identity = new ClaimsIdentity([new(ClaimTypes.NameIdentifier, user.Id.ToString()), new(ClaimTypes.Name, user.Name), new(ClaimTypes.Email, user.Email), new(ClaimTypes.Role, user.Role)], CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync();
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }

    [Authorize, HttpGet]
    public async Task<IActionResult> Profile(CancellationToken ct)
    {
        var u = await Repository.FindUserAsync(UserId!.Value, ct);
        return View(new ProfileForm
        {
            Name = u!.Name,
            Phone = u.Phone,
            Address = u.Address
        }
       );
    }

    [Authorize, HttpPost]
    public async Task<IActionResult> Profile(ProfileForm f, CancellationToken ct)
    {
        if (!ModelState.IsValid) return View(f);
        await Repository.SaveProfileAsync(UserId!.Value, f, ct);
        await SignInAsync((await Repository.FindUserAsync(UserId.Value, ct))!, ct);
        TempData["Message"] = "Đã cập nhật hồ sơ.";
        return RedirectToAction(nameof(Profile));
    }

    [Authorize, HttpPost]
    public async Task<IActionResult> ChangePassword(string currentPassword, string newPassword, string confirmPassword, CancellationToken ct)
    {
        var ok = newPassword == confirmPassword && newPassword.Length >= 8 && newPassword.Length <= 128 && await Repository.ChangePasswordAsync(UserId!.Value, currentPassword, newPassword, ct);
        return MessageRedirect(ok ? "Đã đổi mật khẩu." : "Mật khẩu hiện tại chưa đúng hoặc mật khẩu mới chưa hợp lệ.", "Profile", "Account");
    }

    public IActionResult Denied()
    {
        Response.StatusCode = 403;
        return View();
    }

}
