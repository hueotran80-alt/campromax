using CamPro.Web.Data;

using CamPro.Web.Models;

using CamPro.Web.Services;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

namespace CamPro.Web.Controllers;


[Authorize]
public sealed class CheckoutController(StoreRepository repository, CartService cart, OrderService orders, VnPayService vnPay) : StoreControllerBase(repository)
{

    [HttpGet]
    public async Task<IActionResult> Index(CancellationToken ct)
    {
        var view = await cart.ViewAsync(ct);
        if (view.Lines.Count == 0) return RedirectToAction("Index", "Cart");
        var u = await Repository.FindUserAsync(UserId!.Value, ct);
        var token = Guid.NewGuid().ToString("N");
        HttpContext.Session.SetString("checkoutToken", token);
        ViewBag.Cart = view;
        ViewBag.VnPayReady = vnPay.IsConfigured;
        return View(new CheckoutForm
        {
            Name = u!.Name,
            Email = u.Email,
            Phone = u.Phone,
            Address = u.Address,
            Coupon = view.Coupon,
            SubmissionToken = token
        }
       );
    }

    [HttpPost]
    public async Task<IActionResult> Index(CheckoutForm f, CancellationToken ct)
    {

        if (f.SubmissionToken != HttpContext.Session.GetString("checkoutToken")) ModelState.AddModelError("", "Phiên đặt hàng đã hết hạn. Vui lòng mở lại trang thanh toán.");

        if (f.Payment == "VNPay" && !vnPay.IsConfigured) ModelState.AddModelError("", "VNPay chưa sẵn sàng.");

        if (ModelState.IsValid) try
            {
                var id = await orders.CreateAsync(UserId!.Value, f, ct);
                HttpContext.Session.Remove("coupon");
                if (f.Payment == "VNPay") return Redirect(await vnPay.CreateUrlAsync(id, Email, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1", ct));
                return RedirectToAction("Details", "Orders", new
                {
                    id
                }
               );
            }
            catch (InvalidOperationException ex)
            {
                ModelState.AddModelError("", ex.Message);
            }

        ViewBag.Cart = await cart.ViewAsync(ct);
        ViewBag.VnPayReady = vnPay.IsConfigured;
        return View(f);

    }

}
