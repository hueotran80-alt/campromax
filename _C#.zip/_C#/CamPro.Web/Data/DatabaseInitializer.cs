using MySqlConnector;

namespace CamPro.Web.Data;


public sealed class DatabaseInitializer(MySqlConnectionFactory factory, IWebHostEnvironment environment, ILogger<DatabaseInitializer> logger)
{

    public async Task InitializeAsync(CancellationToken ct)
    {

        // Import Data/Schema.sql first: never silently create another database or reset accounts.
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);

        var schema = await File.ReadAllTextAsync(Path.Combine(environment.ContentRootPath, "Data", "Schema.sql"), ct);

        var start = schema.IndexOf("CREATE TABLE IF NOT EXISTS payment_attempts", StringComparison.Ordinal);

        var end = schema.IndexOf("-- END PAYMENT MIGRATION", start, StringComparison.Ordinal);

        await using var cmd = new MySqlCommand(schema[start..end], cn);
        await cmd.ExecuteNonQueryAsync(ct);

        logger.LogInformation("CAMPRO uses database {Database}.", factory.DatabaseName);

    }

}
