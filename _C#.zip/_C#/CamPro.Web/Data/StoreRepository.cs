using CamPro.Web.Models;

using Microsoft.AspNetCore.Identity;

using MySqlConnector;


namespace CamPro.Web.Data;


public sealed partial class StoreRepository(MySqlConnectionFactory factory)
{

    public async Task<StoreState> GetStateAsync(long? userId, CancellationToken ct)
    {

        await using var cn = factory.Create();

        await cn.OpenAsync(ct);

        var products = await ReadProductsAsync(cn, ct);

        var categories = await ReadCategoriesAsync(cn, ct);

        var suppliers = await ReadSuppliersAsync(cn, ct);

        var customers = await ReadCustomersAsync(cn, ct);

        var orders = await ReadOrdersAsync(cn, ct);

        var coupons = await ReadCouponsAsync(cn, ct);

        var articles = await ReadArticlesAsync(cn, ct);

        var contacts = await ReadContactsAsync(cn, ct);

        var cart = userId is null ? [] : await ReadCartAsync(cn, userId.Value, ct);

        var session = userId is null ? null : customers.FirstOrDefault(x => x.Id == userId.Value)
            ?? await FindUserDtoAsync(cn, userId.Value, ct);

        return new StoreState
        {

            Products = products,
            Categories = categories,
            Suppliers = suppliers,
            Customers = customers,
            Orders = orders,
            Coupons = coupons,
            Articles = articles,
            Contacts = contacts,
            Cart = cart,
            Session = session,
            Compare = []
        }
;

    }


    public async Task<CustomerDto?> LoginAsync(string email, string password, CancellationToken ct)
    {

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);

        await using var cmd = new MySqlCommand("SELECT id,name,email,password_hash,phone,address,role,active FROM users WHERE email=@email LIMIT 1", cn);

        cmd.Parameters.AddWithValue("@email", email.Trim().ToLowerInvariant());

        await using var r = await cmd.ExecuteReaderAsync(ct);

        if (!await r.ReadAsync(ct) || !r.GetBoolean("active")) return null;

        var hasher = new PasswordHasher<object>();

        if (hasher.VerifyHashedPassword(new object(), r.GetString("password_hash"), password) == PasswordVerificationResult.Failed) return null;

        return ReadCustomer(r);

    }


    public async Task<(CustomerDto? User, string? Error)> RegisterAsync(RegisterRequest request, CancellationToken ct)
    {

        var email = request.Email.Trim().ToLowerInvariant();

        if (string.IsNullOrWhiteSpace(request.Name) || !email.Contains('@') || request.Password.Length < 6)
            return (null, "Thông tin đăng ký chưa hợp lệ hoặc mật khẩu dưới 6 ký tự.");

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);

        var id = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        var hash = new PasswordHasher<object>().HashPassword(new object(), request.Password);

        try
        {

            await ExecuteAsync(cn, null, "INSERT INTO users(id,name,email,password_hash,role,active) VALUES(@id,@name,@email,@hash,'customer',1)", ct, ("@id", id), ("@name", request.Name.Trim()), ("@email", email), ("@hash", hash));

            return (new CustomerDto
            {
                Id = id,
                Name = request.Name.Trim(),
                Email = email,
                Active = true,
                Role = "customer"
            }
, null);

        }

        catch (MySqlException ex) when (ex.Number == 1062)
        {
            return (null, "Email đã được đăng ký.");
        }

    }


    public async Task<bool> ChangePasswordAsync(long userId, string current, string next, CancellationToken ct)
    {

        if (next.Length < 6) return false;

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);

        await using var get = new MySqlCommand("SELECT password_hash FROM users WHERE id=@id", cn);
        get.Parameters.AddWithValue("@id", userId);

        var old = (string?)await get.ExecuteScalarAsync(ct);
        if (old is null) return false;

        var hasher = new PasswordHasher<object>();

        if (hasher.VerifyHashedPassword(new object(), old, current) == PasswordVerificationResult.Failed) return false;

        var hash = hasher.HashPassword(new object(), next);

        await ExecuteAsync(cn, null, "UPDATE users SET password_hash=@hash WHERE id=@id", ct, ("@hash", hash), ("@id", userId));
        return true;

    }


    public async Task<bool> PingAsync(CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var cmd = new MySqlCommand("SELECT 1", cn);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct)) == 1;
    }


    private static async Task<List<ProductDto>> ReadProductsAsync(MySqlConnection cn, CancellationToken ct)
    {
        var list = new List<ProductDto>();
        await using var cmd = new MySqlCommand("SELECT * FROM products ORDER BY id", cn);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(new()
        {
            Id = r.GetInt64("id"),
            Name = r.GetString("name"),
            Subtitle = r.GetString("subtitle"),
            Brand = r.GetString("brand"),
            Category = r.GetString("category"),
            Resolution = r.GetString("resolution"),
            Connection = r.GetString("connection_type"),
            Price = r.GetDecimal("price"),
            OldPrice = r.GetDecimal("old_price"),
            Stock = r.GetInt32("stock"),
            Image = r.GetString("image"),
            Tag = r.GetString("tag"),
            Angle = r.GetString("angle"),
            Night = r.GetString("night_mode"),
            Active = r.GetBoolean("active"),
            Description = r.GetString("description")
        }
       );
        return list;
    }

    private static async Task<List<CategoryDto>> ReadCategoriesAsync(MySqlConnection cn, CancellationToken ct)
    {
        var list = new List<CategoryDto>();
        await using var cmd = new MySqlCommand("SELECT * FROM categories ORDER BY id", cn);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(new()
        {
            Id = r.GetInt64("id"),
            Name = r.GetString("name"),
            Description = r.GetString("description"),
            Active = r.GetBoolean("active")
        }
       );
        return list;
    }

    private static async Task<List<SupplierDto>> ReadSuppliersAsync(MySqlConnection cn, CancellationToken ct)
    {
        var list = new List<SupplierDto>();
        await using var cmd = new MySqlCommand("SELECT * FROM suppliers ORDER BY id", cn);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(new()
        {
            Id = r.GetInt64("id"),
            Name = r.GetString("name"),
            Description = r.GetString("description"),
            Email = r.GetString("email"),
            Phone = r.GetString("phone"),
            Active = r.GetBoolean("active")
        }
       );
        return list;
    }

    private static async Task<List<CustomerDto>> ReadCustomersAsync(MySqlConnection cn, CancellationToken ct)
    {
        var list = new List<CustomerDto>();
        await using var cmd = new MySqlCommand("SELECT id,name,email,phone,address,role,active FROM users WHERE role='customer' ORDER BY id", cn);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(ReadCustomer(r));
        return list;
    }

    private static CustomerDto ReadCustomer(MySqlDataReader r) => new()
    {
        Id = r.GetInt64("id"),
        Name = r.GetString("name"),
        Email = r.GetString("email"),
        Phone = r.GetString("phone"),
        Address = r.GetString("address"),
        Role = r.GetString("role"),
        Active = r.GetBoolean("active")
    }
;

    private static async Task<CustomerDto?> FindUserDtoAsync(MySqlConnection cn, long id, CancellationToken ct)
    {
        await using var cmd = new MySqlCommand("SELECT id,name,email,phone,address,role,active FROM users WHERE id=@id", cn);
        cmd.Parameters.AddWithValue("@id", id);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        return await r.ReadAsync(ct) ? ReadCustomer(r) : null;
    }

    private static async Task<List<CouponDto>> ReadCouponsAsync(MySqlConnection cn, CancellationToken ct)
    {
        var list = new List<CouponDto>();
        await using var cmd = new MySqlCommand("SELECT * FROM coupons ORDER BY id", cn);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(new()
        {
            Id = r.GetInt64("id"),
            Code = r.GetString("code"),
            Type = r.GetString("discount_type"),
            Value = r.GetDecimal("discount_value"),
            Min = r.GetDecimal("min_amount"),
            Max = r.GetDecimal("max_amount"),
            Active = r.GetBoolean("active")
        }
       );
        return list;
    }

    private static async Task<List<ArticleDto>> ReadArticlesAsync(MySqlConnection cn, CancellationToken ct)
    {
        var list = new List<ArticleDto>();
        await using var cmd = new MySqlCommand("SELECT * FROM articles ORDER BY id", cn);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(new()
        {
            Id = r.GetInt64("id"),
            Title = r.GetString("title"),
            Category = r.GetString("category"),
            Image = r.GetString("image"),
            Published = r.GetBoolean("published"),
            Body = r.GetString("body")
        }
       );
        return list;
    }

    private static async Task<List<ContactDto>> ReadContactsAsync(MySqlConnection cn, CancellationToken ct)
    {
        var list = new List<ContactDto>();
        await using var cmd = new MySqlCommand("SELECT * FROM contacts ORDER BY created_at DESC,id DESC", cn);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(new()
        {
            Id = r.GetInt64("id"),
            Name = r.GetString("name"),
            Email = r.GetString("email"),
            Phone = r.GetString("phone"),
            Subject = r.GetString("subject"),
            Message = r.GetString("message"),
            Status = r.GetString("status"),
            Reply = r.GetString("reply")
        }
       );
        return list;
    }

    private static async Task<List<CartItemDto>> ReadCartAsync(MySqlConnection cn, long userId, CancellationToken ct)
    {
        var list = new List<CartItemDto>();
        await using var cmd = new MySqlCommand("SELECT product_id,quantity FROM carts WHERE user_id=@id", cn);
        cmd.Parameters.AddWithValue("@id", userId);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) list.Add(new()
        {
            Id = r.GetInt64("product_id"),
            Quantity = r.GetInt32("quantity")
        }
       );
        return list;
    }

    private static async Task<List<OrderDto>> ReadOrdersAsync(MySqlConnection cn, CancellationToken ct)
    {

        var list = new List<OrderDto>();
        await using (var cmd = new MySqlCommand("SELECT * FROM orders ORDER BY order_date DESC,created_at DESC", cn))
        {
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct)) list.Add(new()
            {
                Id = r.GetString("id"),
                Customer = r.GetString("customer"),
                Email = r.GetString("email"),
                ShippingEmail = r.GetString("shipping_email"),
                Phone = r.GetString("phone"),
                Address = r.GetString("address"),
                Note = r.GetString("note"),
                Date = r.GetDateTime("order_date").ToString("yyyy-MM-dd"),
                Total = r.GetDecimal("total"),
                Discount = r.GetDecimal("discount"),
                Status = r.GetString("status"),
                Payment = r.GetString("payment"),
                Paid = r.GetBoolean("paid"),
                Demo = r.GetBoolean("demo")
            }
           );
        }

        var map = list.ToDictionary(x => x.Id);
        await using (var cmd = new MySqlCommand("SELECT * FROM order_items ORDER BY order_id", cn))
        {
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                var id = r.GetString("order_id");
                if (map.TryGetValue(id, out var o)) o.Items.Add(new()
                {
                    Id = r.GetInt64("product_id"),
                    Name = r.GetString("product_name"),
                    Quantity = r.GetInt32("quantity"),
                    Price = r.GetDecimal("price"),
                    Image = r.GetString("image")
                }
               );
            }
        }

        return list;

    }


    private static async Task ExecuteAsync(MySqlConnection cn, MySqlTransaction? tx, string sql, CancellationToken ct, params (string Name, object? Value)[] values)
    {
        await using var cmd = new MySqlCommand(sql, cn, tx);
        foreach (var p in values) cmd.Parameters.AddWithValue(p.Name, p.Value ?? DBNull.Value);
        await cmd.ExecuteNonQueryAsync(ct);
    }

}
