using CamPro.Web.Models;

using MySqlConnector;

namespace CamPro.Web.Data;


public sealed partial class StoreRepository
{

    public async Task<CustomerDto?> FindUserAsync(long id, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        return await FindUserDtoAsync(cn, id, ct);
    }

    public async Task SaveProfileAsync(long id, ProfileForm f, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await ExecuteAsync(cn, null, "UPDATE users SET name=@name,phone=@phone,address=@address WHERE id=@id", ct, ("@name", f.Name.Trim()), ("@phone", f.Phone), ("@address", f.Address), ("@id", id));
    }

    public async Task SaveCartAsync(long userId, List<CartItemDto> items, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);
        await ExecuteAsync(cn, tx, "DELETE FROM carts WHERE user_id=@id", ct, ("@id", userId));
        foreach (var x in items) await ExecuteAsync(cn, tx, "INSERT INTO carts(user_id,product_id,quantity) VALUES(@u,@p,@q)", ct, ("@u", userId), ("@p", x.Id), ("@q", x.Quantity));
        await tx.CommitAsync(ct);
    }

    public async Task CreateContactAsync(ContactForm f, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await ExecuteAsync(cn, null, "INSERT INTO contacts(id,name,email,phone,subject,message,status,reply) VALUES(@id,@name,@email,@phone,@subject,@message,'Chưa xử lý','')", ct, ("@id", DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()), ("@name", f.Name), ("@email", f.Email), ("@phone", f.Phone), ("@subject", f.Subject), ("@message", f.Message));
    }

    public async Task ReplyContactAsync(long id, string reply, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await ExecuteAsync(cn, null, "UPDATE contacts SET reply=@r,status='Đã phản hồi' WHERE id=@id", ct, ("@r", reply), ("@id", id));
    }

    public async Task SetCustomerActiveAsync(long id, bool active, CancellationToken ct)
    {
        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await ExecuteAsync(cn, null, "UPDATE users SET active=@a WHERE id=@id AND role='customer'", ct, ("@a", active), ("@id", id));
    }

    public async Task HideEntityAsync(string entity, long id, CancellationToken ct)
    {

        var sql = entity switch
        {
            "Products" => "UPDATE products SET active=0 WHERE id=@id",
            "Categories" => "UPDATE categories SET active=0 WHERE id=@id",
            "Suppliers" => "UPDATE suppliers SET active=0 WHERE id=@id",
            "Coupons" => "UPDATE coupons SET active=0 WHERE id=@id",
            "Articles" => "UPDATE articles SET published=0 WHERE id=@id",
            _ => throw new ArgumentException("Danh mục không hợp lệ.")
        }
;

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await ExecuteAsync(cn, null, sql, ct, ("@id", id));

    }

    public async Task SaveProductAsync(ProductDto x, CancellationToken ct)
    {

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);
        await ExecuteAsync(cn, tx, "INSERT INTO products(id,name,subtitle,brand,category,resolution,connection_type,price,old_price,stock,image,tag,angle,night_mode,active,description) VALUES(@id,@name,@subtitle,@brand,@category,@resolution,@connection,@price,@oldPrice,@stock,@image,@tag,@angle,@night,@active,@description) ON DUPLICATE KEY UPDATE name=VALUES(name),subtitle=VALUES(subtitle),brand=VALUES(brand),category=VALUES(category),resolution=VALUES(resolution),connection_type=VALUES(connection_type),price=VALUES(price),old_price=VALUES(old_price),stock=VALUES(stock),image=VALUES(image),tag=VALUES(tag),angle=VALUES(angle),night_mode=VALUES(night_mode),active=VALUES(active),description=VALUES(description)", ct,
                               ("@id", x.Id), ("@name", x.Name), ("@subtitle", x.Subtitle), ("@brand", x.Brand), ("@category", x.Category), ("@resolution", x.Resolution), ("@connection", x.Connection), ("@price", x.Price), ("@oldPrice", x.OldPrice), ("@stock", x.Stock), ("@image", x.Image), ("@tag", x.Tag), ("@angle", x.Angle), ("@night", x.Night), ("@active", x.Active), ("@description", x.Description));
        await tx.CommitAsync(ct);

    }

    public async Task SaveCategoryAsync(CategoryDto x, CancellationToken ct)
    {

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);

        await using var find = new MySqlCommand("SELECT name FROM categories WHERE id=@id FOR UPDATE", cn, tx);

        find.Parameters.AddWithValue("@id", x.Id);

        var oldName = await find.ExecuteScalarAsync(ct) as string;

        await ExecuteAsync(cn, tx, "INSERT INTO categories(id,name,description,active) VALUES(@id,@name,@description,@active) ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),active=VALUES(active)", ct,
                        ("@id", x.Id), ("@name", x.Name), ("@description", x.Description), ("@active", x.Active));

        if (oldName is not null && oldName != x.Name)
            await ExecuteAsync(cn, tx, "UPDATE products SET category=@name WHERE category=@old", ct, ("@name", x.Name), ("@old", oldName));

        await tx.CommitAsync(ct);

    }

    public async Task SaveSupplierAsync(SupplierDto x, CancellationToken ct)
    {

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);
        await ExecuteAsync(cn, tx, "INSERT INTO suppliers(id,name,description,email,phone,active) VALUES(@id,@name,@description,@email,@phone,@active) ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),email=VALUES(email),phone=VALUES(phone),active=VALUES(active)", ct,
                               ("@id", x.Id), ("@name", x.Name), ("@description", x.Description), ("@email", x.Email), ("@phone", x.Phone), ("@active", x.Active));
        await tx.CommitAsync(ct);

    }

    public async Task SaveCouponAsync(CouponDto x, CancellationToken ct)
    {

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);
        await ExecuteAsync(cn, tx, "INSERT INTO coupons(id,code,discount_type,discount_value,min_amount,max_amount,active) VALUES(@id,@code,@type,@value,@min,@max,@active) ON DUPLICATE KEY UPDATE code=VALUES(code),discount_type=VALUES(discount_type),discount_value=VALUES(discount_value),min_amount=VALUES(min_amount),max_amount=VALUES(max_amount),active=VALUES(active)", ct,
                               ("@id", x.Id), ("@code", x.Code.ToUpperInvariant()), ("@type", x.Type), ("@value", x.Value), ("@min", x.Min), ("@max", x.Max), ("@active", x.Active));
        await tx.CommitAsync(ct);

    }

    public async Task SaveArticleAsync(ArticleDto x, CancellationToken ct)
    {

        await using var cn = factory.Create();
        await cn.OpenAsync(ct);
        await using var tx = await cn.BeginTransactionAsync(ct);
        await ExecuteAsync(cn, tx, "INSERT INTO articles(id,title,category,image,published,body) VALUES(@id,@title,@category,@image,@published,@body) ON DUPLICATE KEY UPDATE title=VALUES(title),category=VALUES(category),image=VALUES(image),published=VALUES(published),body=VALUES(body)", ct,
                               ("@id", x.Id), ("@title", x.Title), ("@category", x.Category), ("@image", x.Image), ("@published", x.Published), ("@body", x.Body));
        await tx.CommitAsync(ct);

    }

}
