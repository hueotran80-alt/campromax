using CamPro.Web.Data;

using CamPro.Web.Options;

using CamPro.Web.Services;

using Microsoft.AspNetCore.Authentication.Cookies;

using Microsoft.AspNetCore.Mvc;

using System.Threading.RateLimiting;

using Microsoft.AspNetCore.Authentication;

var builder = WebApplication.CreateBuilder(args);

// Local credentials are deliberately separate from distributable source/configuration.
builder.Configuration.AddJsonFile("appsettings.Local.json", optional: true, reloadOnChange: true).AddEnvironmentVariables();

builder.Services.Configure<DatabaseOptions>(builder.Configuration.GetSection(DatabaseOptions.SectionName));

builder.Services.Configure<VnPayOptions>(builder.Configuration.GetSection(VnPayOptions.SectionName));

builder.Services.AddSingleton<MySqlConnectionFactory>();

builder.Services.AddSingleton<DatabaseInitializer>();

builder.Services.AddScoped<StoreRepository>();

builder.Services.AddScoped<CartService>();

builder.Services.AddScoped<OrderService>();

builder.Services.AddScoped<VnPayService>();

builder.Services.AddScoped<ReportService>();

builder.Services.AddMemoryCache();

builder.Services.AddHttpClient("VnPay", client => client.Timeout = TimeSpan.FromSeconds(8));

builder.Services.AddHttpContextAccessor();

builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(o =>
{
    o.Cookie.Name = ".CamPro.Cart";
    o.Cookie.HttpOnly = true;
    o.Cookie.IsEssential = true;
    o.Cookie.SameSite = SameSiteMode.Lax;
    o.IdleTimeout = TimeSpan.FromHours(8);
}
);

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o =>
{

    o.Cookie.Name = ".CamPro.Account";
    o.Cookie.HttpOnly = true;
    o.Cookie.SameSite = SameSiteMode.Lax;

    o.LoginPath = "/Account/Login";
    o.AccessDeniedPath = "/Account/Denied";
    o.ExpireTimeSpan = TimeSpan.FromMinutes(30);
    o.SlidingExpiration = true;

    o.Events.OnValidatePrincipal = async context =>
    {

        if (long.TryParse(context.Principal?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value, out var id))
        {

            var user = await context.HttpContext.RequestServices.GetRequiredService<StoreRepository>().FindUserAsync(id, context.HttpContext.RequestAborted);

            if (user is not null && user.Active && user.Role == context.Principal?.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value) return;

        }

        context.RejectPrincipal();
        await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

    }
;

}
);

builder.Services.AddAuthorization();

builder.Services.AddControllersWithViews(o =>
{

    o.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());

    o.ModelMetadataDetailsProviders.Add(new CamPro.Web.Models.EmptyStringMetadataProvider());

}
);

builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = 429;
    o.AddPolicy("auth", ctx => RateLimitPartition.GetFixedWindowLimiter(ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown", _ => new FixedWindowRateLimiterOptions
    {
        PermitLimit = 12,
        Window = TimeSpan.FromMinutes(1),
        QueueLimit = 0
    }
   ));
}
);

var app = builder.Build();

app.UseExceptionHandler("/Home/Error");

if (!app.Environment.IsDevelopment()) app.UseHsts();

app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
    ctx.Response.Headers["X-Frame-Options"] = "DENY";
    ctx.Response.Headers["Referrer-Policy"] = "strict-origin-when-cross-origin";
    await next();
}
);

app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter();

await app.Services.GetRequiredService<DatabaseInitializer>().InitializeAsync(app.Lifetime.ApplicationStopping);

app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");

app.Run();

public partial class Program;
