namespace CamPro.Web.Models;


public sealed class CouponDto
{

    public long Id
    {
        get;
        set;
    }

    public string Code
    {
        get;
        set;
    }
 = "";

    public string Type
    {
        get;
        set;
    }
 = "percent";

    public decimal Value
    {
        get;
        set;
    }

    public decimal Min
    {
        get;
        set;
    }

    public decimal Max
    {
        get;
        set;
    }

    public bool Active
    {
        get;
        set;
    }

}
