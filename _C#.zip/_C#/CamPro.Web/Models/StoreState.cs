namespace CamPro.Web.Models;


public sealed class StoreState
{

    public List<ProductDto> Products
    {
        get;
        init;
    }
 = [];

    public List<CategoryDto> Categories
    {
        get;
        init;
    }
 = [];

    public List<SupplierDto> Suppliers
    {
        get;
        init;
    }
 = [];

    public List<CustomerDto> Customers
    {
        get;
        init;
    }
 = [];

    public List<OrderDto> Orders
    {
        get;
        init;
    }
 = [];

    public List<CouponDto> Coupons
    {
        get;
        init;
    }
 = [];

    public List<ArticleDto> Articles
    {
        get;
        init;
    }
 = [];

    public List<ContactDto> Contacts
    {
        get;
        init;
    }
 = [];

    public List<CartItemDto> Cart
    {
        get;
        init;
    }
 = [];

    public List<long> Compare
    {
        get;
        init;
    }
 = [];

    public CustomerDto? Session
    {
        get;
        init;
    }

}
