namespace CamPro.Web.Models;


public sealed class CartItemDto
{

    public long Id
    {
        get;
        set;
    }

    public int Quantity
    {
        get;
        set;
    }

}
