using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;


namespace CamPro.Web.Models;


/// <summary>Optional text fields remain empty strings instead of null SQL values.</summary>
public sealed class EmptyStringMetadataProvider : IDisplayMetadataProvider
{

    public void CreateDisplayMetadata(DisplayMetadataProviderContext context)
    {

        if (context.Key.ModelType == typeof(string))
            context.DisplayMetadata.ConvertEmptyStringToNull = false;

    }

}
