namespace CamPro.Web.Models;


public sealed class OrderItemDto
{

    public long Id
    {
        get;
        set;
    }

    public string Name
    {
        get;
        set;
    }
 = "";

    public int Quantity
    {
        get;
        set;
    }

    public decimal Price
    {
        get;
        set;
    }

    public string Image
    {
        get;
        set;
    }
 = "";

}
