namespace CamPro.Web.Models;


public sealed class OrderDto
{

    public string Id
    {
        get;
        set;
    }
 = "";

    public string Customer
    {
        get;
        set;
    }
 = "";

    public string Email
    {
        get;
        set;
    }
 = "";

    public string ShippingEmail
    {
        get;
        set;
    }
 = "";

    public string Phone
    {
        get;
        set;
    }
 = "";

    public string Address
    {
        get;
        set;
    }
 = "";

    public string Note
    {
        get;
        set;
    }
 = "";

    public string Date
    {
        get;
        set;
    }
 = "";

    public List<OrderItemDto> Items
    {
        get;
        set;
    }
 = [];

    public decimal Total
    {
        get;
        set;
    }

    public decimal Discount
    {
        get;
        set;
    }

    public string Status
    {
        get;
        set;
    }
 = "Chờ xử lý";

    public string Payment
    {
        get;
        set;
    }
 = "COD";

    public bool Paid
    {
        get;
        set;
    }

    public bool Demo
    {
        get;
        set;
    }

}
