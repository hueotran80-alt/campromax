using System.ComponentModel.DataAnnotations;

namespace CamPro.Web.Models;


public class LoginForm
{

    [Required, EmailAddress, StringLength(160)]
    public string Email
    {
        get;
        set;
    }
 = "";

    [Required, StringLength(128)]
    public string Password
    {
        get;
        set;
    }
 = "";

    public string? ReturnUrl
    {
        get;
        set;
    }

}

public sealed class RegisterForm : LoginForm
{

    [Required, StringLength(120)]
    public string Name
    {
        get;
        set;
    }
 = "";

    [Required, Compare(nameof(Password), ErrorMessage = "Mật khẩu nhập lại chưa khớp.")]
    public string ConfirmPassword
    {
        get;
        set;
    }
 = "";

}

public sealed class CheckoutForm
{

    [Required, StringLength(120)]
    public string Name
    {
        get;
        set;
    }
 = "";

    [Required, EmailAddress, StringLength(160)]
    public string Email
    {
        get;
        set;
    }
 = "";

    [Required, RegularExpression(@"[0-9 +()-]{9,20}", ErrorMessage = "Số điện thoại chưa hợp lệ.")]
    public string Phone
    {
        get;
        set;
    }
 = "";

    [Required, StringLength(500)]
    public string Address
    {
        get;
        set;
    }
 = "";

    [StringLength(1000)]
    public string Note
    {
        get;
        set;
    }
 = "";

    [Required, RegularExpression("^(COD|VNPay)$")]
    public string Payment
    {
        get;
        set;
    }
 = "COD";

    [StringLength(50)]
    public string Coupon
    {
        get;
        set;
    }
 = "";

    [Required]
    public string SubmissionToken
    {
        get;
        set;
    }
 = "";

}

public sealed class ProfileForm
{

    [Required, StringLength(120)]
    public string Name
    {
        get;
        set;
    }
 = "";

    [StringLength(30)]
    public string Phone
    {
        get;
        set;
    }
 = "";

    [StringLength(500)]
    public string Address
    {
        get;
        set;
    }
 = "";

}

public sealed class ContactForm
{

    [Required, StringLength(120)]
    public string Name
    {
        get;
        set;
    }
 = "";

    [Required, EmailAddress, StringLength(160)]
    public string Email
    {
        get;
        set;
    }
 = "";

    [StringLength(30)]
    public string Phone
    {
        get;
        set;
    }
 = "";

    [Required, StringLength(255)]
    public string Subject
    {
        get;
        set;
    }
 = "";

    [Required, StringLength(5000)]
    public string Message
    {
        get;
        set;
    }
 = "";

}

public sealed record CartLine(ProductDto Product, int Quantity)
{
    public decimal Total => Product.Price * Quantity;
}

public sealed record CartView(List<CartLine> Lines, string Coupon, decimal Discount)
{

    public decimal Subtotal => Lines.Sum(x => x.Total);

    public decimal Total => Subtotal - Discount;

}

public sealed record BestSeller(long ProductId, string Name, string Image, long Quantity, decimal Revenue, long OrderCount);

public sealed record RevenueReport(DateOnly From, DateOnly To, List<OrderDto> Orders, List<BestSeller> BestSellers)
{

    public decimal Revenue => Orders.Sum(x => x.Total);

    public long Quantity => Orders.SelectMany(x => x.Items).Sum(x => (long)x.Quantity);

}

public sealed record PaymentResultView(string? OrderId, bool SignatureValid, string ResponseCode, bool Paid, string Message);

public sealed record EditField(string Name, string Label, string Value, string Type = "text");

public sealed record AdminEditView(string Entity, long Id, string Title, List<EditField> Fields);
