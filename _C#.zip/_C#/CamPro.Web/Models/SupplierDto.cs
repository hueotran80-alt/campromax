namespace CamPro.Web.Models;


public sealed class SupplierDto
{

    public long Id
    {
        get;
        set;
    }

    public string Name
    {
        get;
        set;
    }
 = "";

    public string Description
    {
        get;
        set;
    }
 = "";

    public string Email
    {
        get;
        set;
    }
 = "";

    public string Phone
    {
        get;
        set;
    }
 = "";

    public bool Active
    {
        get;
        set;
    }

}
