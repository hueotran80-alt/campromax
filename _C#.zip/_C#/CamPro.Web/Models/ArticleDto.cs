namespace CamPro.Web.Models;


public sealed class ArticleDto
{

    public long Id
    {
        get;
        set;
    }

    public string Title
    {
        get;
        set;
    }
 = "";

    public string Category
    {
        get;
        set;
    }
 = "";

    public string Image
    {
        get;
        set;
    }
 = "";

    public bool Published
    {
        get;
        set;
    }

    public string Body
    {
        get;
        set;
    }
 = "";

}
