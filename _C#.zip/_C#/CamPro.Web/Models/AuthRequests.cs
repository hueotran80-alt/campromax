namespace CamPro.Web.Models;


public sealed record LoginRequest(string Email, string Password);

public sealed record RegisterRequest(string Name, string Email, string Password);

public sealed record ChangePasswordRequest(string CurrentPassword, string NewPassword);
