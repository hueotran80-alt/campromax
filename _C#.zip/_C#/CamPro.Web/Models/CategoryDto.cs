namespace CamPro.Web.Models;


public sealed class CategoryDto
{

    public long Id
    {
        get;
        set;
    }

    public string Name
    {
        get;
        set;
    }
 = "";

    public string Description
    {
        get;
        set;
    }
 = "";

    public bool Active
    {
        get;
        set;
    }

}
