namespace CamPro.Web.Models;


public sealed class ProductDto
{

    public long Id
    {
        get;
        set;
    }

    public string Name
    {
        get;
        set;
    }
 = "";

    public string Subtitle
    {
        get;
        set;
    }
 = "";

    public string Brand
    {
        get;
        set;
    }
 = "";

    public string Category
    {
        get;
        set;
    }
 = "";

    public string Resolution
    {
        get;
        set;
    }
 = "";

    public string Connection
    {
        get;
        set;
    }
 = "";

    public decimal Price
    {
        get;
        set;
    }

    public decimal OldPrice
    {
        get;
        set;
    }

    public int Stock
    {
        get;
        set;
    }

    public string Image
    {
        get;
        set;
    }
 = "";

    public string Tag
    {
        get;
        set;
    }
 = "";

    public string Angle
    {
        get;
        set;
    }
 = "";

    public string Night
    {
        get;
        set;
    }
 = "";

    public bool Active
    {
        get;
        set;
    }

    public string Description
    {
        get;
        set;
    }
 = "";

}
