namespace CamPro.Web.Models;


public sealed class ContactDto
{

    public long Id
    {
        get;
        set;
    }

    public string Name
    {
        get;
        set;
    }
 = "";

    public string Email
    {
        get;
        set;
    }
 = "";

    public string Phone
    {
        get;
        set;
    }
 = "";

    public string Subject
    {
        get;
        set;
    }
 = "";

    public string Message
    {
        get;
        set;
    }
 = "";

    public string Status
    {
        get;
        set;
    }
 = "Chưa xử lý";

    public string Reply
    {
        get;
        set;
    }
 = "";

}
