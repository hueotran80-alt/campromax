using System.Globalization;

using Microsoft.AspNetCore.Html;

namespace CamPro.Web.Models;


public static class Ui
{

    public static string Money(decimal value) => value.ToString("N0", CultureInfo.GetCultureInfo("vi-VN")) + "₫";

    public static string Image(string filename) => filename.StartsWith("/uploads/", StringComparison.Ordinal) && !filename.Contains("..") ? filename : "/assets/" + Uri.EscapeDataString(Path.GetFileName(filename));

    public static string Badge(string status) => status switch
    {
        "Đã giao" or "Hoàn thành" or "Đã thanh toán" => "success",
        "Đã hủy" => "danger",
        "Đang giao" => "blue",
        _ => ""
    }
;

    public static IHtmlContent Icon(string name)
    {

        var path = name switch
        {

            "cart" => "<path d='M3 3h2l2 13h12l2-9H6'/><circle cx='9' cy='20' r='1'/><circle cx='18' cy='20' r='1'/>",
            "user" => "<circle cx='12' cy='7' r='4'/><path d='M4 22v-3a8 8 0 0 1 16 0v3'/>",
            "search" => "<circle cx='10' cy='10' r='7'/><path d='m15 15 6 6'/>",
            "orders" => "<path d='M6 2h12v20l-3-2-3 2-3-2-3 2zM9 7h6M9 11h6M9 15h4'/>",
            "camera" => "<path d='M3 7h4l2-3h6l2 3h4v14H3z'/><circle cx='12' cy='14' r='4'/>",
            "menu" => "<path d='M3 6h18M3 12h18M3 18h18'/>",
            "check" => "<path d='m4 12 5 5L20 6'/>",
            "shield" => "<path d='m12 2 9 4v6c0 5-9 10-9 10S3 17 3 12V6z'/><path d='m8 12 3 3 5-6'/>",
            "truck" => "<path d='M1 4h13v13H1zM14 9h5l4 5v3h-9'/><circle cx='6' cy='19' r='2'/><circle cx='19' cy='19' r='2'/>",
            "support" => "<path d='M3 15v-3a9 9 0 0 1 18 0v3M3 12H1v7h5v-7zM21 12h2v7h-5v-7zM20 19v3h-7'/>",
            "box" => "<path d='m12 2 10 5v12l-10 5-10-5V7zM2 7l10 5 10-5M12 12v12'/>",
            "arrow" => "<path d='M3 12h18m-6-6 6 6-6 6'/>",
            "logout" => "<path d='M9 3H3v18h6M8 12h14m-5-5 5 5-5 5'/>",
            "chart" => "<path d='M3 3v18h18M7 17v-6M12 17V6M17 17v-9'/>",
            _ => "<path d='M3 12h18m-6-6 6 6-6 6'/>"
        }
;
        return new HtmlString("<svg viewBox='0 0 24 24' aria-hidden='true'>" + path + "</svg>");

    }

}
