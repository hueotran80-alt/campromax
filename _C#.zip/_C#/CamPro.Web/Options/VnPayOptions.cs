namespace CamPro.Web.Options;


public sealed class VnPayOptions
{

    public const string SectionName = "VnPay";

    public string TmnCode
    {
        get;
        set;
    }
 = "";

    public string HashSecret
    {
        get;
        set;
    }
 = "";

    public string Url
    {
        get;
        set;
    }
 = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";

    public string PublicBaseUrl
    {
        get;
        set;
    }
 = "http://localhost:5189";

    public string QueryUrl
    {
        get;
        set;
    }
 = "https://sandbox.vnpayment.vn/merchant_webapi/api/transaction";

    public bool EnableQueryReconciliation
    {
        get;
        set;
    }
 = true;

    public bool IsConfigured => !string.IsNullOrWhiteSpace(TmnCode) && HashSecret.Length >= 16;

}
