# CAMPRO — ASP.NET Core MVC / C# / MySQL

Giao diện cửa hàng và quản trị đã chuyển sang **View Razor (.cshtml)**. Logic xử lý nằm trong **Controller**, **Service** và **Repository C#**. JavaScript chỉ hỗ trợ giao diện và kiểm tra trạng thái thanh toán; không quyết định giá, tồn kho hay kết quả thanh toán.

## Chạy dự án

1. Cài .NET SDK 10 và bật MySQL trong XAMPP.
2. Nếu chưa có database, import **duy nhất `CamPro.Web/Data/Schema.sql`** bằng phpMyAdmin hoặc MySQL Workbench. File tự tạo và chọn **`campro_csharp`**, tạo bảng và dữ liệu mẫu.
3. Nếu database đã có từ bản trước, giữ nguyên dữ liệu. Lần chạy bản MVC chỉ bổ sung bảng lưu giao dịch VNPay và mã chống tạo đơn trùng; không reset tài khoản/sản phẩm/đơn cũ.
4. Nhấp đúp `CHAY_DU_AN.bat`, hoặc mở thư mục dự án trong VS Code và chạy:

```powershell
dotnet run --project .\CamPro.Web\CamPro.Web.csproj
```

- Cửa hàng: http://localhost:5189
- Quản trị: http://localhost:5189/Admin
- Admin: `admin@campro.vn` / `Admin@123`
- Khách hàng mẫu: `minhanh@example.com` / `123456`

Nếu cổng 5189 đang được dùng, dừng phiên chạy cũ trước khi chạy lại. Trong VS Code có sẵn tác vụ Build và cấu hình F5; cần tiện ích C# của Microsoft.

## Database và file SQL

Database chính là **`campro_csharp` trên MySQL**, cấu hình trong `CamPro.Web/appsettings.json` (mặc định 127.0.0.1:3306, root, mật khẩu trống).

`Schema.sql` là file để import cấu trúc và dữ liệu mẫu. Khi khách hàng/Admin cập nhật trên web, C# ghi trực tiếp vào database MySQL. File SQL không tự thay đổi theo các thao tác đó. Không có database `campro` khác trong cấu hình bài này và không có bản SQL thứ hai tại thư mục gốc.

## Thanh toán VNPay tự động

- Tại thanh toán, chọn **Chuyển khoản ngân hàng · VNPay**.
- C# lấy số tiền từ đơn đã lưu, tạo checksum HMAC-SHA512 và chuyển khách sang VNPay Sandbox.
- `/Payment/Ipn` xác minh chữ ký, mã website, mã giao dịch và số tiền. Khi `vnp_ResponseCode=00` và `vnp_TransactionStatus=00`, hệ thống **tự cập nhật `orders.paid=1`** trong MySQL. Admin không có nút xác nhận thủ công cho đơn VNPay.
- Khi khách quay lại, hệ thống có thể **tự truy vấn API querydr của VNPay**. Chỉ phản hồi máy chủ có chữ ký hợp lệ, đúng giao dịch/số tiền và trạng thái thanh toán thành công mới được ghi nhận. Điều này hỗ trợ chạy trên localhost khi IPN chưa truy cập được máy bạn.
- Trang khách hàng tự kiểm tra trạng thái và cập nhật nhãn “Đã thanh toán”. Giao hàng được quản lý riêng: thanh toán thành công không tự chuyển thành “Đã giao”.
- Callback lặp không ghi nhận hai lần; kết quả thất bại không xóa trạng thái thanh toán thành công. Giao dịch đang chờ kết quả không thể bị hủy đơn cùng lúc. Có thể thanh toán lại nếu giao dịch thất bại.

### Cấu hình VNPay

Thông tin Sandbox bạn cung cấp đã được đặt tại **`CamPro.Web/appsettings.Local.json`**. Theo yêu cầu, `.gitignore` không loại file này, `bin/` và `obj/` khỏi Git. File cấu hình local vẫn được loại khỏi bản publish. Không đưa secret vào JavaScript hoặc chia sẻ công khai. Có file mẫu `appsettings.Local.example.json` nếu cần cấu hình trên máy khác.

- `PublicBaseUrl`: mặc định `http://localhost:5189`, dùng cho địa chỉ quay lại. Chạy cùng địa chỉ localhost để giữ phiên đăng nhập.
- `Url`: URL thanh toán Sandbox.
- `QueryUrl`: mặc định API truy vấn Sandbox, không cần sửa khi thử trên máy.
- Khi đưa C# lên hosting, đổi `PublicBaseUrl` thành tên miền HTTPS của bản C#, rồi đăng ký IPN **`https://TEN-MIEN/Payment/Ipn`** với VNPay. Cấu hình secret trên hosting bằng biến môi trường `VnPay__TmnCode` và `VnPay__HashSecret`; không publish file local.
- Đổi sang môi trường thật phải có tài khoản merchant và cấu hình production tương ứng; bản hiện tại là Sandbox.

Tài liệu: [Thanh toán VNPay](https://sandbox.vnpayment.vn/apis/docs/thanh-toan-pay/pay.html), [API truy vấn giao dịch](https://sandbox.vnpayment.vn/apis/docs/truy-van-hoan-tien/querydr%26refund.html).

## Báo cáo doanh thu và top 5

Trang **Admin → Báo cáo doanh thu** có bộ lọc từ ngày/đến ngày. Thống kê theo **ngày đặt đơn**, bao gồm hai đầu khoảng ngày. Đơn đủ điều kiện là **đã thanh toán và đã giao hoặc hoàn thành**; không tính đơn chờ xử lý, chưa thanh toán, đã hủy và đơn mẫu `demo=1`.

- Doanh thu sau giảm giá, số đơn, tổng số lượng bán, giá trị đơn trung bình và biểu đồ theo ngày.
- **Top 5 sản phẩm bán chạy**: cộng `quantity` từ `order_items`, nhóm theo mã sản phẩm, xếp giảm dần theo số lượng; khi bằng nhau, xếp theo doanh thu rồi mã sản phẩm.
- Bảng có hạng, sản phẩm, số lượng bán, số đơn chứa sản phẩm và doanh thu sản phẩm. Giảm giá cấp đơn được phân bổ theo tỷ lệ giá trị các dòng sản phẩm.
- Danh sách đơn tạo nên thống kê để mở chi tiết và đối chiếu số lượng.
- Xuất CSV mở bằng Excel gồm cả đơn hàng và top 5 trong cùng khoảng ngày.

Giá, tên, ảnh và số lượng tại thời điểm đặt hàng được lưu trong `order_items`; sửa sản phẩm về sau không làm sai lịch sử bán hàng. Khi chưa có đơn đủ điều kiện, báo cáo hiển thị trạng thái trống, không sinh số liệu giả.

## Tìm logic trong mã nguồn

```text
CamPro.Web/
  Controllers/               Nhận yêu cầu, kiểm tra quyền, trả View
    AccountController.cs    Tài khoản, hồ sơ, mật khẩu
    ProductsController.cs   Danh sách, tìm kiếm, lọc, so sánh
    CartController.cs       Giỏ hàng và mã giảm giá
    CheckoutController.cs   Đặt hàng và chuyển sang VNPay
    OrdersController.cs     Đơn của khách và trạng thái thanh toán
    PaymentController.cs    IPN / Return của VNPay
    AdminController.cs      Quản trị và báo cáo
  Services/
    CartService.cs          Giỏ hàng và tính giảm giá
    OrderService.cs         Giá, tồn kho, chi tiết đơn, hủy/giao hàng
    VnPayService.cs         Tạo URL, xác minh IPN, tự cập nhật thanh toán
    VnPayService.Reconciliation.cs  Xác minh kết quả querydr
    ReportService.cs        Doanh thu và top 5 sản phẩm
  Models/                   Model và dữ liệu biểu mẫu
  Views/                    Giao diện Razor khách hàng / Admin
  Data/
    StoreRepository.cs      Đọc MySQL, xác thực mật khẩu
    StoreRepository.Operations.cs  Ghi từng dữ liệu được phép
    Schema.sql              File SQL duy nhất để import
  wwwroot/                  CSS, ảnh gốc và JavaScript giao diện
  Program.cs                Đăng ký dịch vụ, bảo vệ phiên, cấu hình MVC
```

Các đường dẫn `#/san-pham`, `#/don-hang`, `#/admin` cũ được chuyển sang trang MVC tương ứng. Dữ liệu trình duyệt của bản cũ không còn được dùng để quyết định dữ liệu đơn hàng.

## Kiểm tra đã thực hiện

- Build C# và Razor không lỗi/cảnh báo; 98 kiểm tra tích hợp đạt, dữ liệu thử được dọn và tồn kho được đối chiếu sau kiểm tra.
- Kiểm tra đăng nhập/phân quyền, CSRF, quyền xem đơn, thanh toán hợp lệ/sai chữ ký/sai tiền/lặp callback, Admin không sửa thanh toán VNPay, đặt hàng COD, hủy đơn và tồn kho.
- Kiểm tra top 5, số lượng từng sản phẩm, đơn bị loại, đổi khoảng ngày và xuất CSV.
- Kiểm tra tự xác nhận qua API querydr bằng máy chủ mô phỏng có chữ ký hợp lệ và không hợp lệ.
- API VNPay Sandbox thật nhận cấu hình và trả mã 91 “Transaction not found” với mã kiểm tra không tồn tại. **Chưa thực hiện giao dịch ngân hàng Sandbox hoàn chỉnh**.

Để chạy lại bộ kiểm tra tích hợp (Python 3, không cần thư viện ngoài), mở server kiểm tra với biến `VnPay__QueryUrl=http://127.0.0.1:5192`, sau đó chạy `python tests/check_flows.py --base-url http://localhost:5191`. Script dựng máy chủ VNPay mô phỏng, tạo dữ liệu riêng, dọn dữ liệu đó và kiểm tra tồn kho được trả lại đúng. Không dùng cấu hình URL mô phỏng khi chạy bình thường.
