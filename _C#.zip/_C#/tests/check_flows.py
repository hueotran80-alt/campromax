"""Integration regression check against a running local app and XAMPP.
Uses isolated temporary records, then removes only those records and restores reserved stock.
Reads VNPay credentials from the local config; never prints them.
"""
from pathlib import Path
import argparse, subprocess, json, uuid, hashlib, hmac
from urllib.parse import urlencode, urlparse, parse_qs
import urllib.request, urllib.error, http.cookiejar
class Response:
    def __init__(self, response):
        self.status_code=response.code; self.headers=response.headers
        self.content=response.read();self.text=self.content.decode('utf-8');self.url=response.url
    def json(self):return json.loads(self.text)
class Session:
    def __init__(self):
        self.cookies=http.cookiejar.CookieJar()
    def request(self,method,url,data=None,params=None,allow_redirects=True,timeout=20,**kwargs):
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self,*args):return None
        handlers=[urllib.request.HTTPCookieProcessor(self.cookies)]
        if not allow_redirects:handlers.append(NoRedirect())
        opener=urllib.request.build_opener(*handlers)
        if params:url+='?'+urlencode(params)
        headers={};body=None
        if data is not None:body=urlencode(data).encode();headers['Content-Type']='application/x-www-form-urlencoded'
        if 'json' in kwargs:body=json.dumps(kwargs['json']).encode();headers['Content-Type']='application/json'
        try:return Response(opener.open(urllib.request.Request(url,data=body,headers=headers,method=method),timeout=timeout))
        except urllib.error.HTTPError as error:return Response(error)
    def get(self,url,**kwargs):return self.request('GET',url,**kwargs)
    def post(self,url,**kwargs):return self.request('POST',url,**kwargs)
import re, html
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import threading, time
def input_value(markup,name):
    for tag in re.findall(r'<input\b[^>]*>',markup):
        attrs=dict(re.findall(r'([\w-]+)="([^"]*)"',tag))
        if attrs.get('name')==name:return html.unescape(attrs.get('value',''))
    raise AssertionError('Missing input '+name)

args=argparse.ArgumentParser()
args.add_argument('--base-url',default='http://localhost:5189')
args.add_argument('--mysql',default=r'C:\xampp\mysql\bin\mysql.exe')
options=args.parse_args()
base=options.base_url.rstrip('/')
config=json.loads((Path(__file__).resolve().parents[1]/'CamPro.Web/appsettings.Local.json').read_text(encoding='utf-8'))['VnPay']
suffix=uuid.uuid4().hex[:12]
email=f'mvc-test-{suffix}@example.com'
other_email=f'mvc-test-other-{suffix}@example.com'
test_order='TST'+suffix
buyer=Session(); other=Session(); admin=Session(); guest=Session()
checks=[]
mock_results={}
class QueryHandler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_POST(self):
        if self.headers.get('Transfer-Encoding')=='chunked':
            body=bytearray()
            while True:
                size=int(self.rfile.readline().strip().split(b';')[0],16)
                if not size:self.rfile.readline();break
                body.extend(self.rfile.read(size));self.rfile.read(2)
            payload=json.loads(body)
        else:payload=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        request_fields=('vnp_RequestId','vnp_Version','vnp_Command','vnp_TmnCode','vnp_TxnRef','vnp_TransactionDate','vnp_CreateDate','vnp_IpAddr','vnp_OrderInfo')
        expected=hmac.new(config['HashSecret'].encode(),'|'.join(payload.get(key,'') for key in request_fields).encode(),hashlib.sha512).hexdigest()
        if payload.get('vnp_SecureHash')!=expected:result={'vnp_ResponseCode':'97'}
        else:result=mock_results.get(payload['vnp_TxnRef'],{'vnp_ResponseCode':'91'})
        body=json.dumps(result).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(body)
query_server=ThreadingHTTPServer(('127.0.0.1',5192),QueryHandler)
threading.Thread(target=query_server.serve_forever,daemon=True).start()
def sql(query):
    result=subprocess.run([options.mysql,'-u','root','--default-character-set=utf8mb4','-N','campro_csharp'],input=query.encode('utf-8'),capture_output=True,check=True)
    return result.stdout.decode('utf-8').strip()
stock_before=sql('SELECT id,stock FROM products ORDER BY id')
def check(condition,name):
    if not condition: raise AssertionError(name)
    checks.append(name)
def get(session,path):
    response=session.get(base+path,timeout=20)
    check(response.status_code==200,'GET '+path.split('?')[0])
    return response
def post(session,form_page,action,values,redirect=True):
    page=get(session,form_page)
    token=input_value(page.text,'__RequestVerificationToken')
    return session.post(base+action,data={'__RequestVerificationToken':token,**values},allow_redirects=redirect,timeout=20)
def signature(values):
    canonical=urlencode(sorted((k,v) for k,v in values.items() if k.startswith('vnp_') and k not in ('vnp_SecureHash','vnp_SecureHashType') and v))
    return hmac.new(config['HashSecret'].encode(),canonical.encode(),hashlib.sha512).hexdigest()
def callback(reference,amount,response='00',status='00',**extra):
    values={'vnp_TmnCode':config['TmnCode'],'vnp_TxnRef':reference,'vnp_Amount':str(amount),'vnp_ResponseCode':response,'vnp_TransactionStatus':status,'vnp_TransactionNo':'9'+uuid.uuid4().hex[:12],'vnp_BankCode':'NCB','vnp_PayDate':'20261006120000',**extra}
    values['vnp_SecureHash']=signature(values)
    return values

try:
    for route in ('/','/Products','/Products/Details/1','/Products/Compare','/Cart','/Contact','/News','/News/Details/1','/Home/Policy','/Account/Login','/Account/Register'):
        get(guest,route)
    check(guest.get(base+'/api/state').status_code==404,'Old global state endpoint removed')
    check(guest.post(base+'/api/state/sync',json={}).status_code==404,'Old global sync endpoint removed')
    check(guest.post(base+'/Cart/Add',data={'id':1,'quantity':1}).status_code==400,'CSRF blocked')
    response=guest.get(base+'/Admin',allow_redirects=False)
    check(response.status_code==302 and '/Account/Login' in response.headers['Location'],'Admin requires authentication')
    response=post(buyer,'/Account/Register','/Account/Register',{'Name':'MVC regression buyer','Email':email,'Password':'TestPass@123','ConfirmPassword':'TestPass@123'})
    check('/Account/Profile' in response.url,'Registration and sign-in')
    post(other,'/Account/Register','/Account/Register',{'Name':'MVC regression other','Email':other_email,'Password':'TestPass@123','ConfirmPassword':'TestPass@123'})
    check(buyer.get(base+'/Admin',allow_redirects=False).status_code==302,'Customer cannot open admin')
    post(buyer,'/Account/Profile','/Account/Profile',{'Name':'MVC regression buyer','Phone':'0901234567','Address':'Test delivery address'})
    post(buyer,'/Products/Details/1','/Cart/Add',{'id':1,'quantity':2})
    post(buyer,'/Products/Details/2','/Cart/Add',{'id':2,'quantity':1})
    post(buyer,'/Cart','/Cart/Coupon',{'code':'CAMPRO10'})
    checkout=get(buyer,'/Checkout')
    values={name:input_value(checkout.text,name) for name in ('SubmissionToken','Coupon')}
    values.update(Name='MVC regression buyer',Email=email,Phone='0901234567',Address='Test delivery address',Note='',Payment='VNPay')
    response=post(buyer,'/Cart','/Checkout/Index',values,redirect=False)
    check(response.status_code==302 and response.headers.get('Location','').startswith(config['Url']),'Checkout redirects to VNPay')
    params={k:v[0] for k,v in parse_qs(urlparse(response.headers['Location']).query).items()}
    check(params.pop('vnp_SecureHash')==signature(params),'Payment URL signature')
    reference=params['vnp_TxnRef']; amount=int(params['vnp_Amount'])
    order_id=sql(f"SELECT order_id FROM payment_attempts WHERE reference='{reference}'")
    check(sql(f"SELECT SUM(quantity) FROM order_items WHERE order_id='{order_id}'")=='3','Order persists line quantities')
    check(sql(f"SELECT paid FROM orders WHERE id='{order_id}'")=='0','New VNPay order unpaid')
    post(buyer,'/Orders/Details/'+order_id,'/Orders/Cancel',{'id':order_id})
    check(sql(f"SELECT status FROM orders WHERE id='{order_id}'")=='Chờ xử lý','In-flight payment cannot race with cancellation')
    get(buyer,'/Orders');get(buyer,'/Orders/Details/'+order_id)
    check(other.get(base+'/Orders/Details/'+order_id).status_code==404,'Other customer cannot read order')
    check(other.get(base+'/Orders/PaymentStatus?id='+order_id).status_code==404,'Other customer cannot read payment state')
    good=callback(reference,amount)
    get(buyer,'/Payment/Return?'+urlencode(good))
    check(sql(f"SELECT paid FROM orders WHERE id='{order_id}'")=='0','Browser return cannot forge paid state')
    wrong=callback(reference,amount+100)
    check(guest.get(base+'/Payment/Ipn',params=wrong).json()['RspCode']=='04','Wrong signed amount rejected')
    tampered={**good,'vnp_Amount':str(amount+100)}
    check(guest.get(base+'/Payment/Ipn',params=tampered).json()['RspCode']=='97','Tampered checksum rejected')
    post(admin,'/Account/Login','/Account/Login',{'Email':'admin@campro.vn','Password':'Admin@123'})
    post(admin,'/Admin/OrderDetails/'+order_id,'/Admin/OrderStatus',{'id':order_id,'status':'Chờ xử lý','paid':'true'})
    check(sql(f"SELECT paid FROM orders WHERE id='{order_id}'")=='0','Admin cannot manually mark VNPay paid')
    check(guest.get(base+'/Payment/Ipn',params=good).json()['RspCode']=='00','Valid VNPay success acknowledged')
    check(sql(f"SELECT paid FROM orders WHERE id='{order_id}'")=='1','VNPay automatically marks database order paid')
    check(buyer.get(base+'/Orders/PaymentStatus',params={'id':order_id}).json()['paid'] is True,'Customer sees paid immediately')
    check(guest.get(base+'/Payment/Ipn',params=good).json()['RspCode']=='02','Duplicate callback idempotent')
    check(guest.get(base+'/Payment/Ipn',params=callback(reference,amount,response='24',status='02')).json()['RspCode']=='02','Late failure cannot downgrade payment')
    post(admin,'/Admin/OrderDetails/'+order_id,'/Admin/OrderStatus',{'id':order_id,'status':'Chờ xử lý','paid':'false'})
    check(sql(f"SELECT paid FROM orders WHERE id='{order_id}'")=='1','Admin cannot clear successful VNPay payment')
    for status in ('Đã xác nhận','Đang giao','Đã giao'):
        post(admin,'/Admin/OrderDetails/'+order_id,'/Admin/OrderStatus',{'id':order_id,'status':status})
    sql(f"UPDATE orders SET order_date='2031-01-15' WHERE id='{order_id}'")
    # Build a deterministic six-product fixture and exclusions without changing stock.
    product_ids=(1,2,3,4,5,7)
    prices={int(line.split('\t')[0]):int(line.split('\t')[1]) for line in sql('SELECT id,price FROM products WHERE id IN (1,2,3,4,5,7)').splitlines()}
    quantities={1:2,2:10,3:7,4:5,5:4,7:1}
    total=sum(prices[p]*q for p,q in quantities.items())
    sql(f"INSERT INTO orders(id,customer,email,phone,address,order_date,total,status,payment,paid) VALUES('{test_order}','Regression fixture','{email}','0901234567','Test','2031-01-02',{total},'Đã giao','COD',1)")
    for pid,qty in quantities.items():
        sql(f"INSERT INTO order_items(order_id,product_id,product_name,quantity,price,image) SELECT '{test_order}',id,name,{qty},price,image FROM products WHERE id={pid}")
    for suffix2,status,paid,date,demo in [('C','Đã hủy',1,'2031-01-02',0),('U','Đã giao',0,'2031-01-02',0),('D','Đã giao',1,'2031-01-02',1),('O','Đã giao',1,'2030-12-31',0)]:
        oid=test_order+suffix2
        sql(f"INSERT INTO orders(id,customer,email,phone,address,order_date,total,status,payment,paid,demo) VALUES('{oid}','Excluded fixture','{email}','0901234567','Test','{date}',990000,'{status}','COD',{paid},{demo}); INSERT INTO order_items(order_id,product_id,product_name,quantity,price,image) VALUES('{oid}',3,'Excluded fixture',999,1,'c225.jpg')")
    report=get(admin,'/Admin/Reports?from=2031-01-01&to=2031-01-31')
    report_text=html.unescape(report.text)
    table=report_text.split('Top 5 sản phẩm bán chạy</h3>')[1].split('<tbody>')[1].split('</tbody>')[0]
    rows=re.findall(r'<tr>(.*?)</tr>',table,re.S)
    quantities_actual=[int(re.sub('<[^>]+>','',re.findall(r'<td>(.*?)</td>',row,re.S)[2]).strip()) for row in rows]
    check(quantities_actual==[11,7,5,4,4],f'Top five aggregates quantities with exclusions and date filter: got {quantities_actual}; order {sql("SELECT CONCAT(status,\"/\",paid) FROM orders WHERE id="+repr(order_id))}')
    check('Excluded fixture' not in report.text,'Reports exclude cancelled/unpaid/demo/outside period')
    outside=get(admin,'/Admin/Reports?from=2032-01-01&to=2032-01-31')
    check('Chưa có sản phẩm đã bán' in html.unescape(outside.text),'Top five respects changed date range')
    export=get(admin,'/Admin/Export?from=2031-01-01&to=2031-01-31')
    check('Top 5' in export.content.decode('utf-8-sig'),'CSV includes top five')
    for path in ('/Admin','/Admin/Orders','/Admin/Customers','/Admin/Contacts'):
        get(admin,path)
    for entity in ('Products','Categories','Suppliers','Coupons','Articles'):
        get(admin,'/Admin/Catalog?entity='+entity)
        get(admin,'/Admin/Edit?entity='+entity+'&id=1')
    # Duplicate checkout token returns the existing order, never deducts inventory twice.
    response=post(buyer,'/Account/Profile','/Checkout/Index',values,redirect=False)
    check(sql(f"SELECT COUNT(*) FROM orders WHERE email='{email}' AND id NOT LIKE 'TST%'")=='1','Duplicate checkout creates one order')
    # A failed/contradictory provider result must never set paid=true; retry gets a fresh reference.
    post(buyer,'/Products/Details/1','/Cart/Add',{'id':1,'quantity':1})
    second=get(buyer,'/Checkout')
    next_values={**values,'Coupon':'','SubmissionToken':input_value(second.text,'SubmissionToken')}
    response=post(buyer,'/Cart','/Checkout/Index',next_values,redirect=False)
    ref2=parse_qs(urlparse(response.headers['Location']).query)['vnp_TxnRef'][0]
    oid2=sql(f"SELECT order_id FROM payment_attempts WHERE reference='{ref2}'")
    amt2=int(sql(f"SELECT amount*100 FROM payment_attempts WHERE reference='{ref2}'"))
    failed=callback(ref2,amt2,response='00',status='02')
    check(guest.get(base+'/Payment/Ipn',params=failed).json()['RspCode']=='00','Provider failure is acknowledged')
    check(sql(f"SELECT paid FROM orders WHERE id='{oid2}'")=='0','Both VNPay success codes required')
    retry=post(buyer,'/Orders/Details/'+oid2,'/Payment/Start',{'id':oid2},redirect=False)
    retry_ref=parse_qs(urlparse(retry.headers['Location']).query)['vnp_TxnRef'][0]
    check(retry_ref!=ref2,'Failed payment retry uses new reference')
    active=post(buyer,'/Orders/Details/'+oid2,'/Payment/Start',{'id':oid2},redirect=False)
    check(parse_qs(urlparse(active.headers['Location']).query)['vnp_TxnRef'][0]==retry_ref,'Active payment reference reused')
    check(guest.get(base+'/Payment/Ipn',params=callback(retry_ref,amt2,response='24',status='02')).json()['RspCode']=='00','User-cancelled payment acknowledged')
    post(buyer,'/Orders/Details/'+oid2,'/Orders/Cancel',{'id':oid2})
    check(sql(f"SELECT status FROM orders WHERE id='{oid2}'")=='Đã hủy','Order can cancel after provider confirms unsuccessful payment')
    # Normal COD and optional empty fields remain functional.
    post(buyer,'/Products/Details/1','/Cart/Add',{'id':1,'quantity':1})
    cod_page=get(buyer,'/Checkout')
    cod_values={**values,'Payment':'COD','Coupon':'','SubmissionToken':input_value(cod_page.text,'SubmissionToken')}
    cod=post(buyer,'/Cart','/Checkout/Index',cod_values,redirect=False)
    check('/Orders/Details/' in cod.headers.get('Location',''),'COD checkout succeeds with empty optional fields')
    cod_id=cod.headers['Location'].split('/')[-1]
    post(buyer,'/Orders/Details/'+cod_id,'/Orders/Cancel',{'id':cod_id})
    check(sql(f"SELECT status FROM orders WHERE id='{cod_id}'")=='Đã hủy','Unpaid COD cancellation works')
    # Localhost fallback uses a server-to-server response, never the browser's claimed success.
    post(buyer,'/Products/Details/1','/Cart/Add',{'id':1,'quantity':1})
    query_page=get(buyer,'/Checkout')
    query_values={**values,'Coupon':'','SubmissionToken':input_value(query_page.text,'SubmissionToken')}
    query_order=post(buyer,'/Cart','/Checkout/Index',query_values,redirect=False)
    query_ref=parse_qs(urlparse(query_order.headers['Location']).query)['vnp_TxnRef'][0]
    query_id=sql(f"SELECT order_id FROM payment_attempts WHERE reference='{query_ref}'")
    query_amount=sql(f"SELECT amount*100 FROM payment_attempts WHERE reference='{query_ref}'")
    provider={'vnp_ResponseId':uuid.uuid4().hex,'vnp_Command':'querydr','vnp_ResponseCode':'00','vnp_Message':'Success','vnp_TmnCode':config['TmnCode'],'vnp_TxnRef':query_ref,'vnp_Amount':query_amount,'vnp_BankCode':'NCB','vnp_PayDate':'20261006120000','vnp_TransactionNo':'9'+uuid.uuid4().hex[:12],'vnp_TransactionType':'01','vnp_TransactionStatus':'00','vnp_OrderInfo':'Regression query'}
    response_fields=('vnp_ResponseId','vnp_Command','vnp_ResponseCode','vnp_Message','vnp_TmnCode','vnp_TxnRef','vnp_Amount','vnp_BankCode','vnp_PayDate','vnp_TransactionNo','vnp_TransactionType','vnp_TransactionStatus','vnp_OrderInfo','vnp_PromotionCode','vnp_PromotionAmount')
    provider['vnp_SecureHash']=hmac.new(config['HashSecret'].encode(),'|'.join(provider.get(key,'') for key in response_fields).encode(),hashlib.sha512).hexdigest()
    mock_results[query_ref]={**provider,'vnp_SecureHash':'0'*128}
    check(buyer.get(base+'/Orders/PaymentStatus',params={'id':query_id}).json()['paid'] is False,'Unsigned query API result rejected')
    mock_results[query_ref]=provider
    time.sleep(16) # Allow the production query throttle to expire.
    check(buyer.get(base+'/Orders/PaymentStatus',params={'id':query_id}).json()['paid'] is True,'Verified server query automatically marks paid without IPN or admin')
    print(f'PASS: {len(checks)} checks; VNPay, authorization, persisted quantities, date-filtered top five.')
finally:
    query_server.shutdown()
    # Only application-created orders reserved stock; hand-built report fixtures did not.
    sql(f"UPDATE products p JOIN (SELECT i.product_id,SUM(i.quantity) quantity FROM order_items i JOIN orders o ON o.id=i.order_id WHERE o.email='{email}' AND o.id NOT LIKE 'TST%' AND o.status<>'Đã hủy' GROUP BY i.product_id) x ON x.product_id=p.id SET p.stock=p.stock+x.quantity; DELETE a FROM payment_attempts a JOIN orders o ON o.id=a.order_id WHERE o.email='{email}'; DELETE s FROM checkout_submissions s JOIN orders o ON o.id=s.order_id WHERE o.email='{email}'; DELETE FROM orders WHERE email='{email}'; DELETE FROM users WHERE email IN ('{email}','{other_email}')")
    assert sql('SELECT id,stock FROM products ORDER BY id')==stock_before,'Test cleanup must restore inventory exactly'
